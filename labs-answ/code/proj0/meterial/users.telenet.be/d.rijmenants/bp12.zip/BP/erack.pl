# erack.pl
# "e"-rack 

if ( scalar(@ARGV) == 0 ) {
	print "Syntaxe: perl erack.pl cipher_file threhold key\n";
	print "    key: UKW left middle right steckers ring\n";
	print "Example: perl erack.pl cipher.txt 10 B I II III AB:CD:ED AAA \n";
	exit(0);
}
$cipherfile = shift;
$threhold = shift;
$key = "@ARGV";


foreach $left ( 'A'..'Z' ) {
  foreach $middle ( 'A'..'Z' ) {
    foreach $right ( 'A'..'Z' ) {
	$grund = $left . $middle . $right;
	open(HD,"M3.exe $key $grund < $cipherfile |");
	$result = <HD>;
	@lettres = split //,$result;
	$nbe = 0;
	for ($i=0;$i<=$#lettres;$i++) {
		if ( $lettres[$i] eq "E" ) { $nbe ++; }
	}
	if ( $nbe > $threhold ) {
		print "==>$grund, $nbe\n";
	}
    }
  }
}





