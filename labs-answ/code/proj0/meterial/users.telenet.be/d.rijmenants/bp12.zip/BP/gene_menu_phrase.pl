#!/usr/bin/perl
# gene_menu_phrase.pl

$PLAIN = shift;
$CIPHER= shift;
$INDEX = shift;

if ( ! defined($CIPHER) ) {
	print( STDERR "Syntaxe: perl gene_menu_phrase.pl PLAIN CIPHER [INDEX]\n");
	print( STDERR " if INDEX is no present, one uses all the characters\n");
	print( STDERR " you can eliminate character with <<.>>\n");
	print( STDERR " you can specifie a turnover with <<t>>\n");
	print( STDERR " Ex: perl gene_menu_phrase.pl BONJOUR WYKGXSB\n");
	print( STDERR " Ex: perl gene_menu_phrase.pl BONJOUR WYKGXSB x..xxx.\n");
	print( STDERR " Ex: perl gene_menu_phrase.pl BONJOUR WYKGXSB xxt.xxx\n");
	die;
}

chomp($PLAIN);
chomp($CIPHER);
$PLAIN =~ s/ *$//;
$CIPHER=~ s/ *$//;
$INDEX = "\L$INDEX";

@tb_plain = split //, $PLAIN;
@tb_cipher= split //, $CIPHER;
@tb_index = split //, $INDEX;


$l1 = @tb_plain;
$l2 = @tb_cipher;
$lg = ( $l1 <= $l2 )?( $l1 ):( $l2 );

if( length($INDEX) < $lg  ) {
	$INDEX = "X" x $lg;
} 

print( STDERR "Plain : $PLAIN\n");
print( STDERR "Cipher: $CIPHER\n");
print( STDERR "Index : $INDEX\n");

#if ( ! defined( $CIPHER)) {
#	printf( STDERR "plain  ? ");
#	$PLAIN = <STDIN>;
#	printf( STDERR "cipher ? ");
#	$CIPHER= <STDIN>;
#}


$INPUT=$tb_plain[0];
$MIDDLE="Z";

printf( STDERR "\n");
for($i=0; $i < $lg; $i++) {
	if ( $tb_index[ $i ] ne "." ) { 
		if ( $tb_index[ $i ] eq "t" ) { 
			$MIDDLE=chr( (((ord($MIDDLE)-65)+1)%26)+65); 
		}
		$RIGHT = chr(65  + ($i%26) );
		printf( STDERR "%s%s%s%s ", $tb_plain[$i], $tb_cipher[$i], 
			$MIDDLE, $RIGHT );
	}
}
printf( STDERR "\n\n");

$MIDDLE="Z";
for($i=0; $i < $lg; $i++) {
	if ( $tb_index[ $i ] ne "." ) { 
		if ( $tb_index[ $i ] eq "t" ) { 
			$MIDDLE=chr( (((ord($MIDDLE)-65)+1)%26)+65); 
		}
		$RIGHT = chr(65  + ($i%26) );
		printf("Z$MIDDLE%s%s%s\n", 
			$RIGHT, $tb_plain[$i], $tb_cipher[$i] );
	}
}
printf("=%s=A=\n", $INPUT );
printf("+++++\n");

