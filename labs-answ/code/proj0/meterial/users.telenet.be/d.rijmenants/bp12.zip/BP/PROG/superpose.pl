# superpose.pl
# "e"-rack 

if ( scalar(@ARGV) == 0 ) {
	print "Syntaxe: perl superpose.pl cipherfile cribfile\n";
	exit(0);
}
$cipherfile = shift;
$cribfile = shift;

open(HD,"$cipherfile") || die("???");
@tb = <HD>;
$text = join("",@tb);
$text = "\U$text";
$text =~ s/[^A-Z]//g ;
close(HD);

open(HD,"$cribfile") || die("???");
@tb = <HD>;
$crib = join("",@tb);
$crib = "\U$crib";
$crib =~ s/[^A-Z]//g ;


@tbt = split //, $text;
@tbc = split //, $crib;
$lg_text = @tbt;
$lg_crib = @tbc;
print $lg_text, " " ,$lg_crib, "\n";

for($i=0;$i<($lg_text - $lg_crib);$i++) {
	# supperose
	$super = 1;
	for $j ( 1..$lg_crib) {
		# print "$i , $j, $tbt[$i+$j-1] eq $tbc[$j-1] \n";
		if ( $tbt[$i+$j-1] eq $tbc[$j-1] ) {
			$super = 0;
		#	print "AIE\n";
		}
	}
	if ($super ) {
		print "$i SUPER\n";
		for $j ( 1..$lg_crib) {	print "$tbt[$i+$j-1]";}
		print "\n";
		for $j ( 1..$lg_crib) {	print "$tbc[$j-1]";}
		print "\n";
	}
}