# eins.pl
# "e"-rack 

if ( scalar(@ARGV) == 0 ) {
	print "Syntaxe: perl eins.pl cipher_file eins key\n";
	print "    eins: a probable word (eins, vieir, vonvon, ...)\n";
	print "    key: UKW left middle right steckers ring\n";
	print "Example: perl eins.pl cipher.txt EINS B I II III AB:CD:ED AAA\n";
	exit(0);
}
$cipherfile = shift;
$eins = shift;
$key = "@ARGV";


foreach $left ( 'A'..'Z' ) {
  foreach $middle ( 'A'..'Z' ) {
    foreach $right ( 'A'..'Z' ) {
	$grund = $left . $middle . $right;
	open(HD,"M3.exe $key $grund < $cipherfile |");
	$result = <HD>;

	if ( index($result,$eins) != -1 ) {
		print "==>$grund, $nbe\n";
	}
    }
  }
}





