// ENIG.c : enigma sans stecker
// un module sous forme objet (pour etre utilise par une bombe)
# include <stdio.h>
# include <string.h>
# include <ctype.h>
# include <stdlib.h>
# include "DIVERS.h"
# include "ENIG.h"


ENIGMA * ENIGMA_new(char * argv1, char *argv2, char * argv3,
 char * argv4, char * argv5, char * argv6, char * argv7 ) {
	ENIGMA * this;

	this = (ENIGMA*)malloc(sizeof(ENIGMA));
	if ( this == NULL ) exit(1);
	this->DoubleStep = FALSE;
	this->ukw    = ROTOR_new( argv1 );
	this->left   = ROTOR_new( argv2 );
	this->middle = ROTOR_new( argv3 );
	this->right  = ROTOR_new( argv4 );
	this->etw    = ROTOR_new( argv5 );

	ROTOR_setRing( this->ukw,    CAR2LETTRE( argv6[0] ));
	ROTOR_setRing( this->left,   CAR2LETTRE( argv6[1] ));
	ROTOR_setRing( this->middle, CAR2LETTRE( argv6[2] ));
	ROTOR_setRing( this->right,  CAR2LETTRE( argv6[3] ));

	ROTOR_setGrund( this->ukw,    CAR2LETTRE( argv7[0] ));
	ROTOR_setGrund( this->left,   CAR2LETTRE( argv7[1] ));
	ROTOR_setGrund( this->middle, CAR2LETTRE( argv7[2] ));
	ROTOR_setGrund( this->right,  CAR2LETTRE( argv7[3] ));

	return this;
}

void ENIGMA_step( ENIGMA * this ) {
	if ( this->DoubleStep ) {
		ROTOR_avance( this->left );
		ROTOR_avance( this->middle );
		this->DoubleStep = FALSE;
	}
	if ( ROTOR_isCarry( this->right ))
		ROTOR_avance( this->middle );		
	if ( ROTOR_isCarry( this->middle )) 
		this->DoubleStep = TRUE;
	ROTOR_avance( this->right );
}

int ENIGMA_chiffre( ENIGMA * this, int x ) {
	int  x1,x2,x3,x4,x5,x6,x7,x8,x9;

	x = x1 = ROTOR_chiffre( this->etw, x );	
	x = x2 = ROTOR_chiffre( this->right,  x );
	x = x3 = ROTOR_chiffre( this->middle, x );
	x = x4 = ROTOR_chiffre( this->left,   x );
	x = x5 = ROTOR_chiffre( this->ukw, x );
	x = x6 = ROTOR_dechiffre( this->left,   x );
	x = x7 = ROTOR_dechiffre( this->middle, x );
	x = x8 = ROTOR_dechiffre( this->right,  x );
	x = x9 = ROTOR_dechiffre( this->etw, x );
/*
	if ( DEBUG ) {
		printf("<%c>", LETTRE2CAR( ROTOR_getGrund(ukw) ));
		printf("<%c>", LETTRE2CAR( ROTOR_getGrund(left) ));
		printf("<%c>", LETTRE2CAR( ROTOR_getGrund(middle) ));
		printf("<%c>", LETTRE2CAR( ROTOR_getGrund(right) ));
		printf(" : %c-->[%c]:%c%c%c(%c)%c%c%c:[%c]-->%c\n",
 		  LETTRE2CAR(x0), LETTRE2CAR(x1), LETTRE2CAR(x2), LETTRE2CAR(x3),
		  LETTRE2CAR(x4), LETTRE2CAR(x5), LETTRE2CAR(x6), LETTRE2CAR(x7),
		  LETTRE2CAR(x8), LETTRE2CAR(x9), LETTRE2CAR(x)
		);
	} else
		printf( "%c", LETTRE2CAR(x) );  // Lamp
	}
*/
	return x;
}
ENIGMA_POS ENIGMA_getPos( ENIGMA * this) {
	ENIGMA_POS pos;
	pos.left  = LETTRE2CAR( ROTOR_getGrund( this->left ));
	pos.middle= LETTRE2CAR( ROTOR_getGrund( this->middle));
	pos.right = LETTRE2CAR( ROTOR_getGrund( this->right));
	return pos;
}
void ENIGMA_setPos( ENIGMA * this, ENIGMA_POS pos) {
	ROTOR_setGrund( this->left,   CAR2LETTRE( pos.left ));
	ROTOR_setGrund( this->middle, CAR2LETTRE( pos.middle));
	ROTOR_setGrund( this->right,  CAR2LETTRE( pos.right));
}


ROTOR * ROTOR_new( char * NomRotor) {
	ROTOR * this;
	char PI[256];
	int tampon[26];
	char NomFic[256];
	char LesNotchs[256];
	FILE * fic;
	int i, NbNotchs;

	strcpy( NomFic, "ROT/" );
	strcat( NomFic, NomRotor);
	strcat( NomFic, ".rot");

	if (!(fic=fopen(NomFic,"r"))) {
		printf("Rotor (%s) inconnu\n", NomFic);
		exit(1);
	}
	fgets( PI, 256, fic );
	fgets( LesNotchs, 256, fic ); 
	fclose(fic);	

	NbNotchs = strlen( LesNotchs ) - 1;

	this = (ROTOR*)malloc(sizeof(ROTOR));
	this -> Index = 0;
	this -> Ring  = 0;
	for(i=0;i<26;i++) {
		this->Notchs[i] = FALSE;
	}
	for(i=0;i<NbNotchs;i++) {
		this->Notchs[ CAR2LETTRE( LesNotchs[i] ) ] = TRUE;
	}
	for(i=0;i<26;i++){
		this -> Decal[i] = (PI[i] - 'A' - i + 26)%26;
	}
	for(i=0;i<26;i++) {
		tampon[ PI[i] - 'A' ] = i;
	}
	for(i=0;i<26;i++){
		this -> Decal_inverse[i] = (tampon[i] - i + 26)%26;
	}
	return this;
}

void ROTOR_avance( ROTOR * this) {
	this -> Index = (this -> Index + 1 )%26;
}

void ROTOR_recule( ROTOR * this) {
	this -> Index = (this -> Index - 1 + 26)%26;
}

BOOL ROTOR_isCarry( ROTOR * this) {
	if ( this -> Notchs[ (this->Index - this->Ring + 26)%26 ] )
		return TRUE;
	else
		return FALSE;
}

LETTRE ROTOR_chiffre( ROTOR * this, LETTRE x) {
	LETTRE y;

	y = (x + this->Decal[ (x + this->Index - this->Ring + 26)%26 ])%26;
	return y;
}

LETTRE ROTOR_dechiffre( ROTOR * this , LETTRE x) {
	LETTRE y;

	y = (x + this->Decal_inverse[ (x + this->Index - this->Ring + 26)%26 ])%26;
	return y;
}

void ROTOR_setGrund( ROTOR * this, LETTRE x) {
	this->Index = x;
}

LETTRE ROTOR_getGrund( ROTOR * this) {
	return this->Index;
}

void ROTOR_setRing( ROTOR * this, LETTRE x) {
	this->Ring = x;
}

