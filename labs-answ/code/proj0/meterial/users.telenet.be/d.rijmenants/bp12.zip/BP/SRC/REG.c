// REG.c
#include <stdio.h>
#include <stdlib.h>
#include "DIVERS.h"
#include "REG.h"

REG * REG_new() {
	int i;
	REG * this;

	this = (REG*)malloc(sizeof(REG));
	if ( this == NULL ) exit(1);
	REG_reset( this );
	return this;
}
	
int REG_set1( REG * this, int port) {
	this->t[port] = 1;
}

int REG_getP( REG * this, int port) {
	return this->t[port];
}

int REG_affiche( REG * this ) {
	int i;

	printf(" [");
	for(i=0;i<26;i++) putchar(this->t[i] + '0');
	printf("] ");
}

int REG_reset( REG * this ) {
	int i;
	for (i=0;i<26;i++) 
		this->t[i]=0;
}

BOOL REG_isFull( REG * this ) {
	int i;
	for (i=0;i<26;i++) 
		if ( this->t[i] == 0) return FALSE;
	return TRUE;
}
BOOL REG_isGood( REG * this ) {
	int i, total;
	for (i=0,total=0; i<26; i++)
		if ( this->t[i] == 1 ) total++;
	return (total==1 || total==25)?(TRUE):(FALSE);
}

int REG_premier( REG * this, BOOL un ) {
	int i;
	if ( un ) {
		for(i=0;i<26;i++)
			if ( this->t[i] == 0 ) return i;
	} else {
		for(i=0;i<26;i++)
			if ( this->t[i] == 1 ) return i;
	} 
}
		
int REG_merge( REG * this, REG * in ) {
	int i;

	for(i=0;i<26;i++)
		this->t[i] |= in->t[i];
}
	
