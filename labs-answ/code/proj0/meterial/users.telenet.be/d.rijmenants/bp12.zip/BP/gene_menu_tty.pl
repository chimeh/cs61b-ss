# tty2bp.pl
# traduire fichier standard teletype en format perso

while ( <> ) {
	$fichier .= $_;
}

$fichier = "\U$fichier";

while( $fichier =~  /(\w\w)(\w)(\w)/mg ) {
	if ( ! $flag ) {
		$INPUT = $1; $flag = 1;
	}
#	print STDERR "[$&] ";
	printf("%s%s%s%s\n", 'Z', $2, $3, $1 );
}

printf("=%s%s=\n", $INPUT, 'A' );
printf("+++++\n");
