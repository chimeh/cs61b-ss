//  DIVERS.h
typedef enum { FALSE, TRUE } BOOL;
typedef char VOID;

