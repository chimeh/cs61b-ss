// checker.c version 4 (essaye de ressembler au manuel US)
// on ne met pas a jour les steckers inverses
# include <stdio.h>
# include <stdlib.h>
# include <string.h>
# include <ctype.h>
# include "DIVERS.h"
# include "LISTE.h"
# include "ENIG.h"
# include "REG.h"
# define MAX_ENIGMA 20
# define MAX_MENU   50

typedef struct{
	BOOL utilisee;
	char lettre_un;
	char lettre_deux;
	ENIGMA_POS pos;
	ENIGMA_POS newpos;
	int off_left;
	int off_middle;
	int off_right;
} MENU;

typedef struct {
	char IN[26];
	char OUT[26];
	BOOL Verifie[26];
	BOOL Menu[26];
} STECKERS;
int affiche_steckers();
int bon_steckers();

STECKERS st;
BOOL FL_step;
BOOL FL_quiet;
BOOL FL_confirme;
BOOL FL_boucle;
BOOL FL_stecker_in;
BOOL FL_indecis;
BOOL FL_stecker_out;
BOOL FL_inverse;
BOOL FL_inv;
BOOL FL_deduction;
BOOL FL_contradiction;
BOOL FL_legalcontra;
BOOL FL_illegal;

main(int argc, char ** argv) {
	char LEFT[20], MIDDLE[20], RIGHT[20], STOP[20], chaine[80];
	char BRIN[30], wheels_start[10], UKW[10];
	char INPUT, ST_IN, STOP_LEFT, STOP_MIDDLE, STOP_RIGHT, lettre;
	FILE * fic;
	int lg_menu, lg_brin, menu_courant, nb_bcl, total, l_in, l_out;
	int lettre_in, lettre_out, lettre_x, lettre_y, menu_in, menu_out;
	int i, j, k, b0, b1, b2, b3, b4, b5, OPTIND, l1, l2;
	int Deduction_l1, Deduction_l2;
	MENU le_menu[ MAX_MENU ];
	ENIGMA_POS pos;
	ENIGMA * enigma;

// 0 - lire les options et les stocker dans des flags et des variables
	strcpy( UKW, "B");
	if ( argc < 8 ) {
		printf("Usage: checker.exe [options] STOP crib left middle");
		printf(" right grund input:stecker\n");
		printf("  -step    : step-by-step\n");
		printf("  -ukw XXX : Uncle Walter (Default: B)\n");
		exit(1);
	}
        for(i=1,OPTIND=0; i< argc; i++) {
                if ( argv[i][0] != '-' ) break;
                // printf("=====>%s\n", argv[i] );
                if ( ! strcmp( argv[i], "-step" )) {
			FL_step = TRUE;
		}
		if ( ! strcmp( argv[i], "-quiet" )) {
			FL_quiet = TRUE;
		}
//              if ( ! strcmp( argv[i], "-b" )) printf("+++ option b ++++\n");
                if ( ! strcmp( argv[i], "-ukw" ))  {
                        OPTIND++;
                        strcpy( UKW , argv[i+1] );
                        printf("UKW: %s\n", UKW );
                        i++;
                }
                OPTIND++;
        }
        for(i=0; i<OPTIND; i++) {
                argv++;
                argc--;
        }

// 1 - lire les arguments et les stocker dans des variables
//     arguments attendus: "STOP menu.crib4 III II I SVG U:I"
// 1.1 traiter les arguments excepte le menu
	if ( argc < 8 ) exit(1);
	if ( strcmp(argv[1],"STOP") != 0 ) exit(1);
	strcpy( LEFT,  argv[3] );
	strcpy( MIDDLE,argv[4] );
	strcpy( RIGHT, argv[5] );
	STOP_LEFT  = argv[6][0];
	STOP_MIDDLE= argv[6][1];
	STOP_RIGHT = argv[6][2];
	INPUT = argv[7][0];
	ST_IN = argv[7][2];
	fprintf(stderr,"===> W.O: %s-%s-%s, W.S: %c%c%c, Input: %c, Stecker: %c\n",
		LEFT, MIDDLE, RIGHT, STOP_LEFT, STOP_MIDDLE, STOP_RIGHT, 
		INPUT, ST_IN 
	);

// 1.2 traiter le menu
        if ( (fic = fopen( argv[2],"r")) == NULL ) exit(1);
        lg_menu=0;
        while( ! feof(fic) ) {
                fgets( chaine, 80, fic );
                b0 = chaine[0]; b1 = chaine[1]; b2 = chaine[2];
                b3 = chaine[3]; b4 = chaine[4];
//		fprintf(stderr,"<%c,%c,%c>,%c,%c\n", b0, b1, b2, b3, b4 );
                if ( b0 == '=' ) continue;
                if ( b0 == '+' ) break;
                pos.left= b0; pos.middle = b1; pos.right = b2;
		le_menu[lg_menu].pos = pos;
		le_menu[lg_menu].lettre_un   = b3;
		le_menu[lg_menu].lettre_deux = b4;
		le_menu[lg_menu].utilisee = FALSE;
                lg_menu ++;
        }
// 2 - realiser les initialisations
// 2.1 - calculer les offsets et les ajouter dans structure MENU
	b3 = le_menu[0].pos.left;
	b4 = le_menu[0].pos.middle;
	b5 = le_menu[0].pos.right;
	le_menu[0].off_left  = 0;
	le_menu[0].off_middle= 0;
	le_menu[0].off_right = 0;

	for(i=1;i<lg_menu; i++) {
		b0 = le_menu[i].pos.left;
		b1 = le_menu[i].pos.middle;
		b2 = le_menu[i].pos.right;
	
		le_menu[i].off_left  = (b0-b3+26)%26; 
		le_menu[i].off_middle= (b1-b4+26)%26;
		le_menu[i].off_right = (b2-b5+26)%26;
				 
	}
	b0 = le_menu[0].newpos.left  = STOP_LEFT;
	b1 = le_menu[0].newpos.middle= STOP_MIDDLE;
	b2 = le_menu[0].newpos.right = STOP_RIGHT;
	for(i=1;i<lg_menu; i++) {
		b3 = le_menu[i].off_left   + b0;
		b4 = le_menu[i].off_middle + b1;
		b5 = le_menu[i].off_right  + b2;

		if ( b3 > 'Z' ) b3 -= 26;
		if ( b4 > 'Z' ) b4 -= 26;
		if ( b5 > 'Z' ) b5 -= 26;

		le_menu[i].newpos.left  = b3;
		le_menu[i].newpos.middle= b4;
		le_menu[i].newpos.right = b5;
	}
	for(i=0;i<lg_menu; i++) {
		fprintf(stderr,"%2d %c%c %c%c%c %c%c%c %d %d %d\n", 
			i+1,
			le_menu[i].lettre_un,
			le_menu[i].lettre_deux,
			le_menu[i].pos.left,
			le_menu[i].pos.middle,
			le_menu[i].pos.right,
			le_menu[i].newpos.left,
			le_menu[i].newpos.middle,
			le_menu[i].newpos.right,
			le_menu[i].off_left,
			le_menu[i].off_middle,
			le_menu[i].off_right
		);
	}


// 2.2 - lister les lettres du menu
	lg_brin = 0;
	BRIN[ lg_brin ++ ] = INPUT;
	fprintf(stderr,"---> First letter : %c\n", BRIN[ lg_brin - 1 ] );
	nb_bcl = 0;

// 2.3 - initialiser le tableau des STECKERS
	for(i=0;i<26;i++) {
		st.IN[i] = i+65;
		st.OUT[i] = -1;
		st.Verifie[i] = FALSE;
		st.Menu[i] = FALSE;
	}
	for(i=0;i<lg_menu;i++) {
		b1 = CAR2LETTRE( le_menu[i].lettre_un );
		b2 = CAR2LETTRE( le_menu[i].lettre_deux);
		st.Menu[ b1 ] = TRUE;
		st.Menu[ b2 ] = TRUE;
	}
	st.OUT[ INPUT-65 ]= ST_IN;
	st.OUT[ ST_IN-65 ]= INPUT;
	affiche_steckers();
	for(i=0;i<26;i++) {
		if ( st.Menu[i] != 0 )
			fprintf(stderr,"P");
		else	fprintf(stderr," ");
	}
	fprintf(stderr,"\n");

// 2.4 - inititalisation pour le premier tour de boucle

//====================================
// 3 - boucle sur les couples du menu
	for(;;) {
		fprintf( stderr, "\n");
// 3.0 - Determiner la lettre courante
		FL_inv = FALSE;
		for(;;) {
			for(i=0;i<lg_menu;i++) {
			  if ( le_menu[i].utilisee ) continue;
			  if ( INPUT == le_menu[i].lettre_un ) goto SUITE;
			  if ( INPUT == le_menu[i].lettre_deux) goto SUITE;
			}
			for(i=0,total=0;i<lg_menu;i++) {
			  if ( le_menu[i].utilisee ) total++;
			}
			if ( total == lg_menu ) goto FIN;  
			for(i=0;i<lg_menu;i++) {
			  if ( le_menu[i].utilisee ) continue;
			  l1 = le_menu[i].lettre_un;
			  l2 = le_menu[i].lettre_deux;
			  for(j=0;j<lg_brin;j++) {
				if ( BRIN[j] == l1 ) {
					INPUT = l1;
					goto CONTINUE;
				}
				if ( BRIN[j] == l2 ) {
					INPUT = l2;
					goto CONTINUE;
				}
			  }
			  // break;
			}
			for(i=0;i<lg_menu;i++) {
			  if ( le_menu[i].utilisee ) continue;
			  j = le_menu[i].lettre_un - 65;
			  k = le_menu[i].lettre_deux - 65;
			  if ( st.OUT[j] == -1 ) {
				if ( st.OUT[k] == -1 )
					continue;
				else 
			  		INPUT = le_menu[i].lettre_deux;
			  } else
			   	INPUT = le_menu[i].lettre_un;
			  lg_brin = 0;
			  BRIN[ lg_brin++ ]= INPUT;
			  goto CONTINUE;
			}
			for(i=0;i<lg_menu;i++) {
			  if ( le_menu[i].utilisee ) continue;
			  INPUT = le_menu[i].lettre_un;
			  lg_brin = 0;
			  BRIN[ lg_brin++ ]= INPUT;
			  goto CONTINUE;
			}
			CONTINUE:;
		}
		goto FIN; // JACKPOT
	SUITE:
		menu_courant = i;
		if ( INPUT == le_menu[i].lettre_un ) {
			menu_in = le_menu[i].lettre_un;
			menu_out= le_menu[i].lettre_deux;
		} else {
			menu_in = le_menu[i].lettre_deux;
			menu_out= le_menu[i].lettre_un;
			FL_inv = TRUE;
		}
		lettre_in = menu_in;
		fprintf(stderr,"Chain: ");
		for(j=0;j<lg_brin;j++)
			fprintf(stderr,"%c", BRIN[j] );
		fprintf(stderr,"\n");

// 3.1 - On applique le stecker � la lettre courante (s'il y en a un)
//       ATTENTION ! il y a une faille : il peut il y avoir un stecker
//       sans qu'on le sache => si inconnu en entree pas de deduction !!!
//======================================================================
		FL_indecis  = FALSE;
		FL_inverse  = FALSE;
		l_in  = menu_in;
		l_out = menu_out;
		if ( st.OUT[ lettre_in - 65 ] >= 0 ) {
			lettre_x = st.OUT[ lettre_in - 65 ];
			FL_stecker_in = TRUE;
		} else {
			lettre_in = menu_out;
			menu_out  = menu_in;
			menu_in   = lettre_in;
			if ( st.OUT[ lettre_in - 65 ] >= 0 ) {
				FL_inverse = TRUE;
				lettre_x = st.OUT[ lettre_in - 65 ];
				FL_stecker_in = TRUE;
			} else {
				lettre_x = lettre_in;
				FL_stecker_in = FALSE;
				FL_indecis    = TRUE;
			}
		}

// 3.2 - On chiffre le r�sultat
		wheels_start[0] = 'A';
		wheels_start[1] = le_menu[ menu_courant ].newpos.left;
		wheels_start[2] = le_menu[ menu_courant ].newpos.middle;
		wheels_start[3] = le_menu[ menu_courant ].newpos.right;
		wheels_start[4] = '\0';
		fprintf(stderr,"wheels start : %s\n", wheels_start + 1 );
                enigma = ENIGMA_new(UKW,LEFT,MIDDLE,RIGHT,"M-ETW",
                        "AAAA", wheels_start 
		);
                lettre_y = ENIGMA_chiffre( enigma, lettre_x - 65 ) + 65;

// 3.3 - S'il y a un stecker, on l'applique, si OK on poursuit, sinon arret BAD
		FL_confirme = FALSE;
		FL_stecker_out = FALSE;
		FL_legalcontra = FALSE;
		if ( st.OUT[ lettre_y - 65 ] >= 0 ) {
			FL_stecker_out = TRUE;
			lettre_out = st.OUT[ lettre_y - 65 ];
			if ( lettre_out != menu_out && ! FL_indecis) {
				if ( FL_stecker_in ) {
				  fprintf(stderr,"(%d) %c->%c->%c->%c\n", 
					menu_courant+1, 
					lettre_in, lettre_x, lettre_y, menu_out
				  );
				  if (st.Menu[lettre_y] && st.Menu[menu_out]){
				    fprintf(stderr,"BAD (illegal contradiction)\n");
				    exit(1);
				  } else {
				    FL_contradiction = TRUE;
				    FL_legalcontra   = TRUE;
				  }
				}
			} else {
				if ( FL_stecker_in ) 
					FL_confirme = TRUE;
			}
		} else    lettre_out = lettre_y;

// 3.4 - On compare le r�sultat avec le menu et on cr�e un stecker si besoin
//       (il y a t il des controles de vraissemblence a faire ? )
		FL_deduction = FALSE;
		if ( ! FL_stecker_out && ! FL_indecis ) {
			st.OUT[ menu_out - 65 ]= lettre_out;
			//st.OUT[ lettre_out - 65 ]= menu_out;
			FL_deduction = TRUE;
			Deduction_l1 = lettre_out;	
			Deduction_l2 = menu_out;
		}
		affiche_steckers();
			
// 3.5 - On flag "le couple du menu", on flag "lettre du menu"
		le_menu[ menu_courant ].utilisee = TRUE;
		FL_boucle = FALSE;
		for(j=0;j<lg_brin;j++) {
			if ( l_out == BRIN[j] ) {
				FL_boucle = TRUE;	
				nb_bcl ++;
			}
		}
		if ( ! FL_boucle )
			BRIN[ lg_brin ++ ] = l_out;

// 3.6 - On affiche les transformations (In->Steck-in ->Chiffre ->Steck-out)
//       On confirme eventuellement des steckers
//       Si on a une boucle, on l'affiche, ...
		if ( FL_indecis )
			lettre_x = lettre_y = lettre_out = '?';
		fprintf(stderr,"(%d) %c->%c->%c->%c", menu_courant+1, 
			lettre_in, lettre_x, lettre_y, menu_out
		);
		if ( FL_inverse ) 
			fprintf(stderr," (inverse) ");
		if ( FL_inv ) 
			fprintf(stderr," (Inverse) ");
		if ( FL_deduction )
			fprintf(stderr," Deduction: %c%c",
				Deduction_l1, Deduction_l2
			);
		if ( FL_confirme ) {
			if ( ! st.Verifie[ lettre_in - 65 ] ) {
			  fprintf(stderr,"  Confirmation: %c%c",
			    st.IN[ lettre_in - 65 ], st.OUT[ lettre_in -65]
			  );
			  st.Verifie[ lettre_in - 65 ] = TRUE;
			}
			if ( ! st.Verifie[ menu_out - 65 ] ) {
			  fprintf(stderr," Confirmation: %c%c",
			    st.IN[ menu_out - 65 ], st.OUT[ menu_out - 65]
			  );
			  st.Verifie[ menu_out - 65 ] = TRUE;
			}
		}
		if ( FL_boucle ) {
			fprintf(stderr, " Loop: ");
			for(j=0;j<lg_brin;j++)
				fprintf(stderr,"%c",BRIN[j]);
			fprintf(stderr,"(%c)", menu_out );
		}
		if ( FL_legalcontra ) { 
			fprintf(stderr, " Legal Contradiction");
		}
		fprintf(stderr,"\n");

// 3.7 - On initialise les valeurs pour le prochain tour de boucle
		INPUT = menu_out;		

		if ( FL_step ) {
			printf("?"); gets(chaine);
		}
	}
FIN:
	for(i=0;i<25;i++) {
		for(j=i+1;j<26;j++) 
			if ( st.OUT[i] == st.OUT[j ] &&  st.OUT[i] != -1 )  {
				FL_contradiction = TRUE;
				if ( st.Menu[i] && st.Menu[j] 
			  && st.Menu[st.OUT[i]-65] && st.Menu[st.OUT[j]-65] )
					FL_illegal = TRUE;
			}
	}
	if ( ! FL_contradiction ) { 
		printf("STORY ");
	} else if ( ! FL_illegal ) { 
		printf("GOOD_STOP ");
	} else {
		printf("BAD_STOP" );
	}
	printf(" W.O: %s-%s-%s, W.S: %c%c%c, ",
		LEFT, MIDDLE, RIGHT, STOP_LEFT, STOP_MIDDLE, STOP_RIGHT
	);
	printf("Steckers: ");
	bon_steckers();
	printf(" Loops: %d", nb_bcl );
	printf("\n");
	exit(0);
}

int affiche_steckers() {
	int i;

	for(i=0;i<26;i++) {
		fprintf(stderr,"%c", st.IN[i]);
	}
	fprintf(stderr,"\n");
	for(i=0;i<26;i++) {
		if ( st.OUT[i] >= 0 )
			fprintf(stderr,"%c", st.OUT[i]);
		else	fprintf(stderr,".");
	}
	fprintf(stderr,"\n");
}

int bon_steckers() {
	int i;

	for(i=0;i<26;i++) {
		if ( st.OUT[i] >= 0 ) {
			if ( st.Verifie[i] )
				printf("(%c%c) ", st.IN[i], st.OUT[i] );
			else
				printf("%c%c ", st.IN[i], st.OUT[i] );
	//		st.OUT[ st.OUT[i] - 65 ] = 0;
		}
	}
}
// ==================================
