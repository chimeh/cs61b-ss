# ring.pl
# find ringstellung from indicator

if ( scalar(@ARGV) == 0 ) {
	print "Syntaxe: perl ring.pl Ring_of_rotor_right messageKey indicators key\n";
	print "Example: perl ring.pl F GBP HOW MEL B I II III AB:CD:EF\n";
	exit(0);
}
$ringR= shift;
$messageKey = shift;
$startIndicator = shift;
$indicator = shift;
$key = "@ARGV";


print "$ringR,$messageKey,$startIndicator,$indicator,$key\n";

foreach $left ( 'A'..'Z' ) {
  foreach $middle ( 'A'..'Z' ) {
	$ring = $left . $middle . $ringR;
	open(HD,"echo $indicator |M3.exe $key $ring $startIndicator|");
	$result = <HD>;
	($lettreL,$lettreM,$lettreR) = split //,$result;
	
	$decalL = ord($left) - ord('A');
	$decalM = ord($middle) - ord('A');
	$lettreL = chr( ((26 +(ord($lettreL)-65)-$decalL)%26)+65);
	$lettreM = chr( ((26 +(ord($lettreM)-65)-$decalM)%26)+65);
	$plain = $lettreL . $lettreM . $lettreR;
	if ( $plain eq $messageKey) {
		print "RING: $ring";
	}
  }
}





