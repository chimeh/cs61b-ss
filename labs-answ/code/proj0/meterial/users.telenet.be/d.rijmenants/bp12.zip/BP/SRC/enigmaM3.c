// enigmaM3.c
# include <stdio.h>
# include <string.h>
# include <ctype.h>
# include <stdlib.h>

typedef int LETTRE;
typedef enum{FALSE,TRUE} BOOL;
typedef struct {
	int Decal[26];
	int Decal_inverse[26];
	int Index;
	LETTRE Ring;
	BOOL Notchs[26];
} ROTOR;
# define CAR2LETTRE(x)  ((x)-'A')
# define LETTRE2CAR(x)  ((x)+'A')

ROTOR * ROTOR_new(char *);
LETTRE ROTOR_chiffre( ROTOR *, LETTRE);
LETTRE ROTOR_dechiffre( ROTOR *, LETTRE);
void ROTOR_setGrund( ROTOR *, LETTRE );
void ROTOR_setRing( ROTOR *, LETTRE );
LETTRE ROTOR_getGrund( ROTOR *);
void ROTOR_avance( ROTOR *);
void ROTOR_recule( ROTOR * this);
BOOL ROTOR_isCarry( ROTOR * this);

typedef struct {
	int s[26];
} STECKER;

STECKER * STECKER_new( char * LesSteckers );
LETTRE STECKER_chiffre( STECKER * this, LETTRE x);

main(int argc, char **argv) {
	char ch[256];
	int car;
	int flag_skip;
	LETTRE x, x0, x1,x2,x3,x4,x5,x6,x7, x8, x9;
	ROTOR * reflec, * left, * middle, * right;
	STECKER * steck;
	BOOL DoubleStep = FALSE;
	BOOL DEBUG = FALSE;

	if ( argc < 8 ) {
		printf("Usage: enigmaM3 <UKW> <left> <midlle> <right>");
		printf(" <steckers> <ring> <grun> [Debug]\n");
		printf("   exemple: enigmaM3 B I II III BH:DP:CN SDF GBP\n");
		printf("   BONJOUR -> WYKQ XSB\n"); 
		exit(1);
	}
	reflec = ROTOR_new( argv[1] );
	left   = ROTOR_new( argv[2] );
	middle = ROTOR_new( argv[3] );
	right  = ROTOR_new( argv[4] );
	steck  = STECKER_new( argv[5] );

	ROTOR_setRing( left,   CAR2LETTRE( argv[6][0] ));
	ROTOR_setRing( middle, CAR2LETTRE( argv[6][1] ));
	ROTOR_setRing( right,  CAR2LETTRE( argv[6][2] ));

	ROTOR_setGrund( left,   CAR2LETTRE( argv[7][0] ));
	ROTOR_setGrund( middle, CAR2LETTRE( argv[7][1] ));
	ROTOR_setGrund( right,  CAR2LETTRE( argv[7][2] ));
	if ( argc > 8 ) DEBUG = TRUE;

	while( (car = getchar()) != -1  ) {
		if ( car == '.' ) { flag_skip = 1; car = 'A'; } else { flag_skip = 0; }
		x = x0 = CAR2LETTRE(toupper(car));
		if (!(x>=0 && x<26)) continue; 

		if ( DoubleStep ) {
			ROTOR_avance( left );
			ROTOR_avance( middle );
			DoubleStep = FALSE;
		}
		if ( ROTOR_isCarry( right ))
			ROTOR_avance( middle );		
		if ( ROTOR_isCarry( middle )) 
			DoubleStep = TRUE;
		ROTOR_avance( right );

		x = x1 = STECKER_chiffre( steck, x );	
		x = x2 = ROTOR_chiffre( right,  x );
		x = x3 = ROTOR_chiffre( middle, x );
		x = x4 = ROTOR_chiffre( left,   x );
		x = x5 = ROTOR_chiffre( reflec, x );
		x = x6 = ROTOR_dechiffre( left,   x );
		x = x7 = ROTOR_dechiffre( middle, x );
		x = x8 = ROTOR_dechiffre( right,  x );
		x = x9 = STECKER_chiffre( steck, x );

		if ( flag_skip ) { x = '.' - 'A'; }
		if ( DEBUG ) {
			printf("<%c>", LETTRE2CAR( ROTOR_getGrund(left) ));
			printf("<%c>", LETTRE2CAR( ROTOR_getGrund(middle) ));
			printf("<%c>", LETTRE2CAR( ROTOR_getGrund(right) ));
			printf(" : %c-->[%c]:%c%c%c(%c)%c%c%c:[%c]-->%c\n",
 			  LETTRE2CAR(x0), LETTRE2CAR(x1), LETTRE2CAR(x2), LETTRE2CAR(x3),
			  LETTRE2CAR(x4), LETTRE2CAR(x5), LETTRE2CAR(x6), LETTRE2CAR(x7),
			  LETTRE2CAR(x8), LETTRE2CAR(x9), LETTRE2CAR(x)
			);
		} else
			printf( "%c", LETTRE2CAR(x) );  // Lamp
	}

}

ROTOR * ROTOR_new( char * NomRotor) {
	ROTOR * this;
	char PI[256];
	int tampon[26];
	char NomFic[256];
	char LesNotchs[256];
	FILE * fic;
	int i, NbNotchs;

	strcpy( NomFic, "ROT/" );
	strcat( NomFic, NomRotor);
	strcat( NomFic, ".rot");

	if (!(fic=fopen(NomFic,"r"))) exit(1);
	fgets( PI, 256, fic );
	fgets( LesNotchs, 256, fic ); 
	fclose(fic);	

	NbNotchs = strlen( LesNotchs ) - 1;

	this = (ROTOR*)malloc(sizeof(ROTOR));
	this -> Index = 0;
	this -> Ring  = 0;
	for(i=0;i<26;i++) {
		this->Notchs[i] = FALSE;
	}
	for(i=0;i<NbNotchs;i++) {
		this->Notchs[ CAR2LETTRE( LesNotchs[i] ) ] = TRUE;
	}
	for(i=0;i<26;i++){
		this -> Decal[i] = (PI[i] - 'A' - i + 26)%26;
	}
	for(i=0;i<26;i++) {
		tampon[ PI[i] - 'A' ] = i;
	}
	for(i=0;i<26;i++){
		this -> Decal_inverse[i] = (tampon[i] - i + 26)%26;
	}
	return this;
}

void ROTOR_avance( ROTOR * this) {
	this -> Index = (this -> Index + 1 )%26;
}

void ROTOR_recule( ROTOR * this) {
	this -> Index = (this -> Index - 1 + 26)%26;
}

BOOL ROTOR_isCarry( ROTOR * this) {
	if ( this -> Notchs[ this -> Index] )
		return TRUE;
	else
		return FALSE;
}

LETTRE ROTOR_chiffre( ROTOR * this, LETTRE x) {
	LETTRE y;

	y = (x + this->Decal[ (x + this->Index - this->Ring + 26)%26 ])%26;
	return y;
}

LETTRE ROTOR_dechiffre( ROTOR * this , LETTRE x) {
	LETTRE y;

	y = (x + this->Decal_inverse[ (x + this->Index - this->Ring + 26)%26 ])%26;
	return y;
}

void ROTOR_setGrund( ROTOR * this, LETTRE x) {
	this->Index = x;
}

LETTRE ROTOR_getGrund( ROTOR * this) {
	return this->Index;
}

void ROTOR_setRing( ROTOR * this, LETTRE x) {
	this->Ring = x;
}

STECKER * STECKER_new( char * LesSteckers ) {
	STECKER * this;
	int i,lg;
	LETTRE x, y;

	this = (STECKER *)malloc(sizeof(STECKER));
	for(i=0;i<26;i++) {
		this->s[i]=i;
	}
	lg = strlen(LesSteckers);
	for(i=0;i<lg;i+=3) {
		x = CAR2LETTRE( LesSteckers[i] );
		y = CAR2LETTRE( LesSteckers[i+1]);
		this->s[x] = y;
		this->s[y] = x;			
	}
	return this;
}

LETTRE STECKER_chiffre( STECKER * this, LETTRE x) {
	return this->s[x];
}
