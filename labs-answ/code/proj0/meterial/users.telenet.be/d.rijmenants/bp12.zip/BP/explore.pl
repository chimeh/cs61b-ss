# explore.pl

while( $ligne = <> ) {
	chomp($ligne);
	system("check.exe $ligne 2>err");
}
