// LISTE.c
# include <stdio.h>
# include <stdlib.h>
# include "DIVERS.h"
# include "LISTE.h"

LISTE * LISTE_new() {
	LISTE * this;
	this = (LISTE*) malloc( sizeof(LISTE));
	this -> Tete = NULL;
	this -> Queue = NULL;
	this -> Courant = NULL;
	return this;
}
VOID LISTE_append( LISTE * this, VOID * elt ) {
	this -> Courant = (struct NOEUD*) malloc( sizeof(struct NOEUD) );
	this -> Courant -> suivant = NULL;
	this -> Courant -> elt = elt;
	if ( this -> Tete == NULL )
		this -> Tete = this -> Courant;
	else
		this -> Queue -> suivant = this -> Courant;
	this -> Queue = this -> Courant;
}
VOID LISTE_rewind( LISTE * this ) {
	this -> Courant = this -> Tete;
}
BOOL LISTE_courant( LISTE * this, VOID ** pelt ) {
	if ( this -> Courant == NULL ) return FALSE;
	* pelt =  this -> Courant -> elt;
	this -> Courant = this -> Courant -> suivant;
	return TRUE;
}

