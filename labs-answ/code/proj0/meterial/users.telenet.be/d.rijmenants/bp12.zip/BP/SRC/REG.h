// REG.h

typedef struct {
	int t[26];
} REG;

REG * REG_new();
	
int REG_set1( REG * this, int port);
int REG_getP( REG * this, int port);
int REG_affiche( REG * this );
int REG_reset( REG * this );
BOOL REG_isFull( REG * this );
BOOL REG_isGood( REG * this );
int REG_premier( REG * this, BOOL un);
int REG_merge( REG * this, REG * in);

