// ENIG.h : enigma sans stecker
// un module sous forme objet (pour etre utilise par une bombe)

typedef int LETTRE;
typedef struct {
	int Decal[26];
	int Decal_inverse[26];
	int Index;
	LETTRE Ring;
	BOOL Notchs[26];
} ROTOR;
# define CAR2LETTRE(x)  ((x)-'A')
# define LETTRE2CAR(x)  ((x)+'A')

ROTOR * ROTOR_new(char *);
LETTRE ROTOR_chiffre( ROTOR *, LETTRE);
LETTRE ROTOR_dechiffre( ROTOR *, LETTRE);
void ROTOR_setGrund( ROTOR *, LETTRE );
void ROTOR_setRing( ROTOR *, LETTRE );
LETTRE ROTOR_getGrund( ROTOR *);
void ROTOR_avance( ROTOR *);
void ROTOR_recule( ROTOR * this);
BOOL ROTOR_isCarry( ROTOR * this);

typedef struct {
	ROTOR * ukw;
	ROTOR * four;
	ROTOR * left;
	ROTOR * middle;
	ROTOR * right;
	ROTOR * etw;
	BOOL DoubleStep;
} ENIGMA;

typedef struct {
	int four;
	int left;
	int middle;
	int right;
} ENIGMA_POS;

int ENIGMA_chiffre( ENIGMA * this, int x );
void ENIGMA_step( ENIGMA * this );
ENIGMA_POS ENIGMA_getPos( ENIGMA * this);
void ENIGMA_setPos( ENIGMA * this, ENIGMA_POS pos);
ENIGMA * ENIGMA_new( char * argv1, char * argv2, char * argv3, char * argv4,
	char * argv5, char * argv6, char * argv7, char * argv8
);

