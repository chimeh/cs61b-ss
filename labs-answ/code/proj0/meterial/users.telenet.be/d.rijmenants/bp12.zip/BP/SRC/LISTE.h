// LISTE.h

struct NOEUD {
	VOID *  elt;
	struct NOEUD * suivant;
};

typedef struct {
	struct NOEUD * Tete;
	struct NOEUD * Queue;
	struct NOEUD * Courant;
} LISTE;

LISTE * LISTE_new();
VOID LISTE_append( LISTE * this, VOID * elt );
VOID LISTE_rewind( LISTE * this );
BOOL LISTE_courant( LISTE * this, VOID ** pelt );
