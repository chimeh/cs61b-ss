# les_bombes.pl

$crib = shift;
( defined( $crib ) ) || die("syntaxe : les_bombes.pl fichier_crib");
$nbruns = shift;
$arguments = shift;

@mini = ( "I:II:III", "I:III:II", "II:I:III",
          "II:III:I", "III:I:II", "III:II:I"
);

@soixante = (
	"I:II:III", "I:III:II", "II:I:III", "II:III:I", "III:I:II", "III:II:I",
	"I:II:IV",  "I:IV:II",  "II:I:IV",  "II:IV:I",  "IV:I:II",  "IV:II:I",
	"I:II:V",   "I:V:II",   "II:I:V",   "II:V:I",   "V:I:II",   "V:II:I",
	"I:III:IV", "I:IV:III", "III:I:IV", "III:IV:I", "IV:I:III", "IV:III:I",
	"I:III:V",  "I:V:III",  "III:I:V",  "III:V:I",  "V:I:III",  "V:III:I",
	"I:IV:V",   "I:V:VI",   "IV:I:V",   "IV:V:I",   "V:I:IV",   "V:IV:I",
	"II:III:IV","II:IV:III","III:II:IV","III:IV:II","IV:II:III","IV:III:II",
	"II:III:V", "II:V:III", "III:II:V", "III:V:II", "V:II:III", "V:III:II",
	"II:IV:V",  "II:V:IV",  "IV:II:V",  "IV:V:II",  "V:II:IV",  "V:IV:II",
	"III:IV:V", "III:V:IV", "IV:III:V", "IV:V:III", "V:III:IV", "V:IV:III"
);	
	
%rotors = (
	1 => "I",
	2 => "II",
	3 => "III",
	4 => "IV",
	5 => "V",
	6 => "VI",
	7 => "VII",
	8 => "VIII",
);
for($i=1;$i<9;$i++) {
	for($j=1;$j<9;$j++) {
		next if ( $i == $j );
		for($k=1;$k<9;$k++) {
			next if ( $k == $j || $k == $i );
			push( @naval, "$rotors{$i}:$rotors{$j}:$rotors{$k}" );
		}
	}

}
if ( $nbruns eq "soixante" ) {
	@combinaisons = @soixante; 
} elsif ( $nbruns eq "naval") {
	@combinaisons = @naval;
} else {
	@combinaisons = @mini; 
}
$i=0;
foreach $valzenage ( @combinaisons ) {
	@wheels = split /:/, $valzenage;
	$i++;
	printf( STDERR "===> (%2d) ", $i );
        print STDERR "@wheels\n";
	system("bombe.exe $arguments $crib @wheels");
}
