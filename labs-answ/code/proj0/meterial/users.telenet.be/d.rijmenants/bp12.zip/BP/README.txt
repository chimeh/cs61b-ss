How to use the BP Software, in brief (BP=Bombe Project) version 1.2  (28/01/07)

======= Description
This Bombe simulator try to look like a real three rotors Bombe.
principal features :
- By default, a stop shows uniquely one stecker, but with a option 
  (machine gun) you can see the others 
- The Grundstellung of each couple of letters is completly specified 
  (on three letters)
- You can use the Navy rotors (VI, VII, VIII)
- You can create rotors : the are stored in a file (in the ROT directory)
- You can use the Bletchley Park conventions and compare result with
  result of wartime (cf.US 6812 Bombe Report)
- You can use or not the diagonal Board
- You can create a "Throw on" menu which use register out of Diagonal Board
 
and it succeed all the tests of "US 6812 Bombe Report"!

======= A : A simple use

1) Make a Crib file.
2) Start the bomb.

Example:
+++++++++++++++++++++++++++
E:\BP>type ellsbury.cri4
ZZABE
ZZBED
ZZCAB
ZZDCG
ZZEHE
ZZFHA
ZZGEH
ZZHAD
ZZIDB
=E=A=
+++++

E:\BP>bombe ellsbury.cri4 II I III
STOP ellsbury.cri4 II I III BGX E:X
++++++++++++++++++++++++++++++++++++++++++++

The Crib file format:
- Each line begins with the positions of the rotors followed by a couple 
of letters: the cipher letter and plain letter which correspond. 
- The line "=E=A=" says: input the courant at letter "E" of the menu into
terminal "A".
- The line "+++++" ends the file

	5        Enigma 012345678
   A-----H       Grund. ABCDEFGHI
  /|     ||      plain  BEACHHEAD
7/ |2   4||6     cipher EDBGEAHDB
D--B-----E
|8    0  |       Input letter: E, terminal: A
|   1    |       4 loops
----------

The arguments of Bombe software: the name of the Crib file and the rotors used 
(I, II, III, IV, V, VI, VII and VIII). If the software finds solutions, 
it prints the word "STOP" following by the Walzenage, the Grundstellung and 
the plug which correspond at the input letter.


======B : Search through all rotors positions


We use a perl software called les_bombes.pl, the arguments are: the name of 
the Crib file followed by the numbers of runs:
- "mini", which use only the rotors I to III (by default)
- "soixante", which use the rotors I to V
- "naval", which use the rotors I to VIII
Next, the arguments passed to the Bombe software.
You can redirect result into a file with ">".

Examples:
+++++++++++++++++++++++++++
E:\BP>perl les_bombes.pl ellsbury.cri4 soixante
===> ( 1) I II III
===> ( 2) I III II
===> ( 3) II I III
STOP ellsbury.cri4 II I III BGX E:X
===> ( 4) II III I
===> ( 5) III I II
===> ( 6) III II I
STOP ellsbury.cri4 III II I EFO E:N
===> ( 7) I II IV
�
===> (58) IV V III
===> (59) V III IV
===> (60) V IV III
STOP ellsbury.cri4 V IV III JOW E:O

E:\BP>perl les_bombes.pl ellsbury.cri4 mini > result
===> ( 1) I II III
===> ( 2) I III II
===> ( 3) II I III
===> ( 4) II III I
===> ( 5) III I II
===> ( 6) III II I

E:\BP>more result
STOP ellsbury.cri4 II I III BGX E:X
STOP ellsbury.cri4 III II I EFO E:N

E:\BP>

+++++++++++++++++++++++++++
We also can use the run_sixty.bat software. It doesn't require Perl interpreter.

+++++++++++++++++++++++++++

E:\BP>run_sixty ellsbury.cri4 > result

E:\BP>type result
===( 1) I II III
===( 2) I II IV
STOP ellsbury.cri4 I II IV NKJ E:J
===( 3) I II V
STOP ellsbury.cri4 I II V VED E:P
STOP ellsbury.cri4 I II V XDK E:Q
STOP ellsbury.cri4 I II V XTJ E:P
===( 4) I III II
===( 5) I III IV
===( 6) I III V
...
===(60) V IV III
STOP ellsbury.cri4 V IV III JOW E:O
+++++++++++++++++++++++++++

======C : Advanced uses

The Bombe software has several options. You can print them by launch software
without arguments. 

Here there are some examples:
+++++++++++++++++++++++++++
E:\BP>bombe.exe
Usage: bomb3r [options] crib left middle right
  -step     : Stop after each grundstellung
  -stop     : Stop after each stop
  -register : Print registers
  -printall : Print all registers
  -notestall: No test all registers
  -back     : Back one a position for a stop
  -mg       : Machine Gun
  -sss      : Self-steckers needed (SSS)
  -csko     : Steckers no adjacent (CSKO)
  -nodiag   : Not use Diagonal Board
  -bp       : Use BP notation, use drums B-* !
  -ukw XXX  : Uncle Walter (Default: B)
  -ws XXX   : Wheels Start (Default: AAA)
  -ring XXX : Ringstellung (default: AAA)

E:\BP>bombe.exe -mg ellsbury.cri4 II I III
STOP ellsbury.cri4 II I III BGX E:X AW BN DP EX HG

E:\BP>bombe.exe -mg ellsbury.cri4 III II I
machine_gun ellsbury.cri4 III II I EFO E:N AI BL DZ EN HZ

+++++++++++++++++++++++++++
If the software print "machine_gun" instead of "STOP", the Stop was rejected 
when the others registers were analyzed. 


+++++++++++++++++++++++++++

======D : all softwares

bombe.exe		The Turing Bombe software
les_bombes.pl		Active bombe.exe for each wheels order (Perl software)
run_sixty.bat		A msdos batch version of "les_bombes.pl" software
run_mini.bat		Mini job with only 3 rotors (I,II,III)
letch.exe		A checker machine (an Enigma without plugs)
check.exe		Try to discover the plugs for one stop. 
			It is an automate version of letch
M3.exe			A text version of an Enigma
gene_menu_phrase.pl	
gene_menu_tty.pl	Software which generate a Crib file
explore.pl		A program which can automate the launching of 
			check.exe software	
erack.pl		This program search the wheel start position of 
			a message
eins.pl			This program search the wheel start position of 
			a message
ring.pl			This program search the Ringstellung with given 
			indicators
superpose.pl		This program search the right position of a crib

===========================================================================
Others examples and challenges are found in "BP\PROBLEM\" directory. 
The solutions are in "BP\PROBLEM\SOLUTION\" directory. The file
"table_of_contents" list the problems in create and difficulty order.

The "BP\DOC" directory contain many informations about the bombe and its 
use. The BP\DOC\TOOLS gives indication how to use software.
===========================================================================
How to install PERL software

1) Download PERL
You can find it on the ActiveState site:
http://www.activestate.com/Products/ActivePerl/

2) Install it (follow the instructions)
===========================================================================
Other Bombe simulators:

- Turing Bombe, by N. Shaylor
http://frode.web.cern.ch/frode/crypto/Shaylor/bombe.html

- Turing Bombe, by Andy Carlson
http://homepages.tesco.net/~andycarlson/enigma/bombemodel.html

- Turing Bombe, by Tony Sale
http://www.codesandciphers.org.uk/virtualbp/hsbombe/intro.htm


Remark: Those simulators cannot succeed all the tests of 
"US 6812 Bombe Report"!
===========================================================================
Thanks:

I thank Philip C. Marks. He has given me the corrections of menus of the
US 6812 Bombe Report. These corrections proved me that my software was
right.

===========================================================================
Links: 

- Codes and Ciphers in the Second World War, by Tony Sale 
(This site homes many interesting things about Enigma and Bombe, 
among other things, the "US 6812 Bombe Report".)
http://www.codesandciphers.org.uk/

- The US 6812th Division Report on the British Bombe, 1944
http://www.codesandciphers.org.uk/documents/bmbrpt/index.htm

- Cipher Machines and Cryptology, by Dirk Rijmenants
(This site homes a beautiful graphic Enigma simulator and many
informations about Enigma).
http://users.telenet.be/d.rijmenants/

- Frode Weierud's CryptoCellar, by Frode Weierud
(This site homes many interesting about Enigma, among other
things real messages from Enigma)
http://home.cern.ch/frode/crypto/

- The British Bombe, The Rebuild Project, by John Harper
http://www.jharper.demon.co.uk/bombe1.htm

- The Enigma and the Bombe, by Graham Ellsbury
http://www.ellsbury.com/enigmabombe.htm

- Solving the Enigma
http://www.nsa.gov/publications/publi00016.cfm

- Cryptanalysis of the Enigma, from Wikipedia, the free encyclopedia
http://en.wikipedia.org/wiki/Cryptanalysis_of_the_Enigma

- Bletchley Park
http://www.bletchleypark.org.uk/

- The Alan Turing Internet Scrapbook
http://www.turing.org.uk/turing/scrapbook/ww2.html

- IN FRENCH: La bombe de Turing, par Didier M�ller
http://www.apprendre-en-ligne.net/crypto/Enigma/bombe.html

============================================================================
Mailto:

If you have questions, or remarks, or if you see mistakes, you can send 
me a mail :

<Jean-Fran�ois BOUCHAUDY>  jfbouch@wanadoo.fr
