// ENIGMA.h

typedef struct {
	int data[8][26];
	int pos[3];
	int step[3];
	int double_step;
	int order[3];
} ENIGMA;

typedef struct {
	int left;
	int middle;
	int right;
} ENIGMA_POS;

void ENIGMA_step( ENIGMA * this );

int ENIGMA_chiffre( ENIGMA * this, int c );

ENIGMA * ENIGMA_new( char * walz, char * grund );

ENIGMA_POS ENIGMA_getPos( ENIGMA * this );

void ENIGMA_setPos( ENIGMA * this, ENIGMA_POS pos );
