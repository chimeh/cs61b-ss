// b_tur11.c
// on essaye une vrai bombe (avec un registre)
// on utilise des options (SSS, CHKS, MG) et noeud ?
// on essaye d'introduire notation BP
// on essaye d'avoir "step" qui marche et menu de Tony Sale 
# include <stdio.h>
# include <string.h>
# include <stdlib.h>
# include <ctype.h>
# include "DIVERS.h"
# include "LISTE.h"
# include "ENIG.h"
# include "REG.h"
# define MAX_ENIGMA 36
# define MAX_REGISTER  40
typedef struct {
	char IN[26];
	char OUT[26];
} STECKERS;
int noeud( int indice, int x, int y);
int diag( int x, int y );
int affiche();
int steckers();

ENIGMA * e[ MAX_ENIGMA ];
REG * r[ MAX_REGISTER ];
BOOL flag[ 26 ];
STECKERS les_steck;
int Cour_init[ 26 ];
int NbInput;
int FL_FLAG;
int FL_register;
int FL_back;
int FL_step;
int FL_stop;
int FL_printall;
int FL_nodiag;
int FL_stop_OK;
int FL_testall;
int FL_mg;
int FL_mg_OK;
int FL_sss;
int FL_sss_OK;
int FL_csko;
int FL_csko_OK;
int FL_bp;
int FL_ts;

main(int argc, char ** argv) {
        int i,j,k,r_l, r_m, r_r,car,lg_crib, b0, b1, b2, b3, b4, b5;
	int min_l, min_m, min_r;
	int lettre, courant, nbi, OPTIND, indice_reg, reg_in, reg_out;
	int bits1, des1;
	int DEBUT_left, DEBUT_middle, DEBUT_right;
        char * ch, chaine[80], WheelStart[10], RINGSTELLUNG[10];
	char UncleWalter[10];
	FILE * fic;
	ENIGMA_POS pos, * ppos, tpos[ MAX_ENIGMA ];
	LISTE * lst;


//====== quelques initialisations ==============
	FL_step = FL_stop = FL_register = FL_back = FL_nodiag = FALSE;
	FL_testall = FL_mg = FL_sss = FL_csko = FL_bp = FL_ts = FALSE;
	strcpy( RINGSTELLUNG, "AAAA");
	strcpy( UncleWalter,"B");
	DEBUT_left = DEBUT_middle = DEBUT_right = 0;

//====== on traite les options =================
	if ( argc < 5 ) {
		printf("Usage: bomb3r [options] crib left middle right\n");
		printf("  -step     : Stop after each grundstellung\n");
		printf("  -stop     : Stop after each stop\n");
		printf("  -register : Print registers\n");
		printf("  -printall : Print all registers\n");
		printf("  -testall  : Test all registers\n");
		printf("  -back     : Back one a position for a stop\n");
		printf("  -mg       : Machine Gun\n");
		printf("  -sss      : Self-steckers needed (SSS)\n");
		printf("  -csko     : Steckers no adjacent (CSKO)\n");
		printf("  -nodiag   : Not use Diagonal Board\n");
		printf("  -bp       : Use BP notation, use drums B-* !\n");
		printf("  -ts       : Use Tony Sale notation, use -ring ZZZ\n");
		printf("  -ukw XXX  : Uncle Walter (Default: B)\n");
		printf("  -ws XXX   : Wheels Start (Default: AAA)\n");
		printf("  -ring XXX : Ringstellung (default: AAA)\n");
		exit(1);
	}
	for(i=1,OPTIND=0; i< argc; i++) {
                if ( argv[i][0] != '-' ) break;
		FL_FLAG = FALSE;
         	//printf("=====>%s\n", argv[i] );
                if ( ! strcmp( argv[i], "-step" )) {
			FL_step = TRUE;
			FL_FLAG = TRUE;
		}
                if ( ! strcmp( argv[i], "-stop" )) {
			FL_stop = TRUE;
			FL_FLAG = TRUE;
		}
                if ( ! strcmp( argv[i], "-register" )) {
			FL_register = TRUE;
			FL_FLAG = TRUE;
		}
                if ( ! strcmp( argv[i], "-back" )) {
			FL_back = TRUE;
			FL_FLAG = TRUE;
		}
                if ( ! strcmp( argv[i], "-printall" )) {
			FL_printall = TRUE;
			FL_FLAG = TRUE;
		}
                if ( ! strcmp( argv[i], "-testall" )) {
			FL_testall = TRUE;
			FL_FLAG = TRUE;
		}
                if ( ! strcmp( argv[i], "-nodiag" )) {
			FL_nodiag = TRUE;
			FL_FLAG = TRUE;
		}
                if ( ! strcmp( argv[i], "-mg" )) {
			FL_mg= TRUE;
			FL_FLAG = TRUE;
		}
                if ( ! strcmp( argv[i], "-sss" )) {
			FL_sss= TRUE;
			FL_FLAG = TRUE;
		}
                if ( ! strcmp( argv[i], "-csko" )) {
			FL_csko= TRUE;
			FL_FLAG = TRUE;
		}
                if ( ! strcmp( argv[i], "-bp" )) {
			FL_bp = TRUE;
			FL_FLAG = TRUE;
		}
                if ( ! strcmp( argv[i], "-ts" )) {
			FL_ts = TRUE;
			FL_FLAG = TRUE;
		}
                if ( ! strcmp( argv[i], "-ws" ))  {
                        OPTIND++;
                        strcpy( WheelStart, argv[i+1] );
			DEBUT_left  = CAR2LETTRE( WheelStart[0] );
			DEBUT_middle= CAR2LETTRE( WheelStart[1] );
			DEBUT_right = CAR2LETTRE( WheelStart[2] );
                        printf("WO: %s\n", WheelStart );
                        i++;
			FL_FLAG = TRUE;
                }
                if ( ! strcmp( argv[i], "-ukw" ))  {
                        OPTIND++;
                        strcpy( UncleWalter, argv[i+1] );
                        printf("UKW: %s\n", UncleWalter);
                        i++;
			FL_FLAG = TRUE;
                }
                if ( ! strcmp( argv[i], "-ring" ))  {
                        OPTIND++;
                        strcpy( RINGSTELLUNG+1, argv[i+1] );
                        printf("Ring: %s\n", RINGSTELLUNG);
                        i++;
			FL_FLAG = TRUE;
                }
                OPTIND++;
		if ( ! FL_FLAG ) {
			printf("====Option incorrect !!!\n");
			exit(1);
		}
	}
	for(i=0; i<OPTIND; i++) {
		argc--;
		argv++;
	}

//++++++++++++++++++++++++++++++++++++++++++++++
	lst = LISTE_new();
	lg_crib=0;
	min_l = min_m = min_r = 'Z';
	if ( (fic = fopen( argv[1],"r")) == NULL ) {
		printf("Le fichier Crib ne peut etre ouvert\n");
		exit(1);
	}
	while( ! feof(fic) ) {			
		fgets( chaine, 80, fic );
		b0 = chaine[0]; b1 = chaine[1]; b2 = chaine[2];
		b3 = chaine[3]; b4 = chaine[4];
// printf("<%c,%c,%c>,%c,%c\n", b0, b1, b2, b3, b4 );
		if ( b0 == '+' ) break;
		if ( b0 == '=' ) {
			lettre  = ( b1 & 0xFF) -'A';
			courant = ( b3 & 0xFF);
			Cour_init[ lettre ] = courant;
			NbInput ++;
			continue;
		}
		b3 &= 0xFF;  b4 &= 0xFF;
		if ( b3 >= '0' && b3 <= '=' ) b3 = ( b3 - '0' ) + 26;
		else if ( b3 >= 'A' && b3 <= 'Z' ) { 
			b3 -= 'A';
			flag[b3]=1;
		}
		else exit(3);
		if ( b4 >= '0' && b4 <= '=' ) b4 = ( b4 - '0' ) + 26;
		else if ( b4 >= 'A' && b4 <= 'Z' ) {
			b4 -= 'A';
			flag[b4]=1;
		}
		else exit(3);

		pos.left= b0; pos.middle = b1; pos.right = b2;
		tpos[ lg_crib ] = pos;

		if ( b0 < min_l ) {
			min_l = b0; min_m = b1; min_r = b2;
		} else if ( b0 <= min_l && b1 < min_m ) {
			min_l = b0; min_m = b1; min_r = b2;
		} else if ( b0 <= min_l && b1 <= min_m && b2 < min_r ) {
			min_l = b0; min_m = b1; min_r = b2;
		}
		ppos = malloc( sizeof(ENIGMA_POS));
		ppos->right = lg_crib; ppos->middle = b3; ppos->left = b4;
		LISTE_append( lst, (VOID*)ppos );
		ppos = malloc( sizeof(ENIGMA_POS));
		ppos->right = lg_crib; ppos->middle = b4; ppos->left = b3;
		LISTE_append( lst, (VOID*)ppos );
		lg_crib ++;
	}
//	printf("MIN: %c%c%c\n", min_l, min_m, min_r );

//for(i=0;i<26;i++) {
//	if ( Cour_init[i] )
//		printf("Input: %c, Courant: %c\n", i+'A', Cour_init[i] );
//}

	if ( lg_crib == MAX_ENIGMA ) {
		printf("Crib trop long\n");
		exit(1);
	}
	for(i=0;i<lg_crib;i++) {
		e[i] = ENIGMA_new(UncleWalter,argv[2],argv[3],argv[4],"M-ETW",
			RINGSTELLUNG,"AAAA" );
	}
//	for( LISTE_rewind(lst); LISTE_courant(lst,(VOID**) &ppos);) {
//		i = ppos->right;
//		printf("[%2d]<%c><%c>:<%c%c%c>\n", ppos->right, 
//			ppos->middle+'A', ppos->left+'A' ,
//			tpos[i].left, tpos[i].middle, tpos[i].right
//		);
//	}

	for(i=0;i<MAX_REGISTER;i++) {
		r[i] = REG_new();
	}
//======+++++++======== DEBUT GRANDE BOUCLE ======++++++=============
	for(r_l= DEBUT_left    ;r_l<26;r_l++)
	 for(r_m= DEBUT_middle ;r_m<26;r_m++)
	  for(r_r= DEBUT_right ;r_r<26;r_r++) {
		for(i=0;i<lg_crib;i++) {
  			pos = tpos[i];
			pos.left  = (((pos.left  -'A')+ r_l)%26)+'A';
			pos.middle= (((pos.middle-'A')+ r_m)%26)+'A';
			pos.right = (((pos.right -'A')+ r_r)%26)+'A';
			ENIGMA_setPos( e[i], pos );
		}
//  	pos = ENIGMA_getPos( e[0] );
//  	printf( "<<%c,%c,%c>>\n",
//    		pos.left, pos.middle, pos.right
//  	);
//
//--------------------- debut du test ------------------------------
	for(j=0;j<MAX_REGISTER;j++) REG_reset( r[j] );
	for(j=0;j<26;j++) {
		if ( Cour_init[j] )
			REG_set1( r[j], Cour_init[j]-'A' );
	}
	FL_stop_OK = FALSE;
	for(j=0;j<20;j++) {
//		affiche(); printf("=====%d\n", j);
		for( LISTE_rewind(lst); LISTE_courant(lst,(VOID**) &ppos);) {
			indice_reg= ppos->right;
			reg_in  =  ppos->middle;
			reg_out =  ppos->left;
			noeud( indice_reg, reg_in, reg_out );
			if ( ! FL_nodiag ) {
				for(k=0;k<26;k++) {
					if ( reg_in < 26 )
						diag( reg_in,k);
					if ( reg_out < 26 )
						diag( reg_out,k);
				}
			}
 		}
		for(k=0,nbi=0; k<26 && nbi < NbInput; k++) {
			if ( Cour_init[k] )
				if ( REG_isFull( r[k] )) goto STEP;
		}
	}
	if ( FL_testall ) {
		for(j=0;j<26;j++)
			if ( REG_isFull( r[j] )) goto STEP;	
	}
	FL_stop_OK = TRUE;
	if ( FL_register )
		affiche();  
	pos = ENIGMA_getPos( e[0] );
	if ( FL_back ) {
		if ( pos.right > 'A' ) pos.right--; else pos.right='Z';
	}
	for(i=0, bits1=0;i<26;i++) {
		if ( flag[i] ) {
			for(j=0;j<26;j++)
				if( REG_getP( r[i] , j )) bits1 ++;
			break;
		}
	}
	if ( bits1 > 1 ) des1 = 1; else des1 = 0;
// 	REG_affiche( r[lettre] );
	steckers();
	if ( FL_mg || FL_sss  || FL_csko ) {
		if ( FL_sss && ! FL_sss_OK ) {
  		printf( "sss %s %s %s %s %c%c%c %c:%c\n",
		argv[1], argv[2], argv[3], argv[4],
    		pos.left, pos.middle, pos.right, lettre + 'A',
		REG_premier( r[lettre], des1 ) + 'A'
  		);
			goto STEP;
		}
		if ( FL_csko && ! FL_csko_OK ) {
  		printf( "csko %s %s %s %s %c%c%c %c:%c\n",
		argv[1], argv[2], argv[3], argv[4],
    		pos.left, pos.middle, pos.right, lettre + 'A',
		REG_premier( r[lettre], des1 ) + 'A'
  		);
			goto STEP;
		}
		if ( FL_mg && ! FL_mg_OK ) {
  		printf( "machine_gun %s %s %s %s %c%c%c %c:%c",
		argv[1], argv[2], argv[3], argv[4],
    		pos.left, pos.middle, pos.right, lettre + 'A',
		REG_premier( r[lettre], des1 ) + 'A'
  		);
		for(i=0;i<26;i++) {
			if ( les_steck.OUT[i] )
				printf(" %c%c", les_steck.IN[i], les_steck.OUT[i] );
		}
		printf("\n");
			goto STEP;
		}
	}
  	printf( "STOP %s %s %s %s ",
		argv[1], argv[2], argv[3], argv[4]
	);
	if ( ! FL_bp && ! FL_ts ) {
		printf("%c%c%c ",
    			pos.left, pos.middle, pos.right
		);
	} else if ( FL_bp ) {
		b0 = (25 - (r_l + 25 )%26) + 'A';
		b1 = (25 - (r_m + 25 )%26) + 'A';
		b2 = (25 - (r_r + 25 )%26) + 'A';
		printf("%c%c%c ", b0, b1, b2 );
	} else if ( FL_ts ) {
		b0 = ((r_l + 25)%26) + 'A';
		b1 = ((r_m + 25)%26) + 'A';
		b2 = ((r_r + 25)%26) + 'A';
		printf("%c%c%c ", b0, b1, b2 );
	}
	printf("%c:%c", lettre + 'A', REG_premier( r[lettre], des1 ) + 'A');
	if ( FL_mg ) {
		for(i=0;i<26;i++) {
			if ( les_steck.OUT[i] )
				printf(" %c%c", les_steck.IN[i], les_steck.OUT[i] );
		}
	}
	printf("\n");
	if ( FL_stop ) {
		printf("?");gets(chaine);
	}
	STEP:;
	if ( FL_step && ! FL_stop_OK ) {
		if ( FL_register ) affiche();
		pos = ENIGMA_getPos( e[0] );
  		printf( "Grund : <%c%c%c> ",pos.left, pos.middle, pos.right);
		printf("?");gets(chaine);
	}
	}  // Fin grande boucle	
	exit(0);
}

int noeud( int indice, int x, int y) {
	int i, j;
	ENIGMA_POS pos;
	for(i=0;i<26;i++) {
		if ( REG_getP( r[x], i)) {
			j = ENIGMA_chiffre( e[indice], i );
			REG_set1( r[y], j );
		}
	}
}
int affiche() {
	int i,j, bits1, des1;
	for(i=0, bits1=0;i<26;i++) {
		if ( flag[i] ) {
			for(j=0;j<26;j++)
				if( REG_getP( r[i] , j )) bits1 ++;
			break;
		}
	}
	if ( bits1 > 1 ) des1 = 1; else des1 = 0;
	printf("      ABCDEFGHIJKLMNOPQRSTUVWXYZ\n");
	for(i=0;i<26;i++) {
		if ( flag[i] || FL_printall ) {
			printf("%c : ", i + 'A' );
			REG_affiche( r[i] );
			printf(" %c", i+'A' );
			if ( REG_isGood( r[i] ) )
				printf("%c", REG_premier( r[i], des1 )+ 'A');
			else
				printf("?");
			if ( Cour_init[i] ) 
				printf(" *, courant:%c", Cour_init[i]);
			printf("\n");
		}
	}
}
int diag( int x, int y ) {
	if ( REG_getP( r[x], y )) {
		REG_set1( r[y], x ); //printf("=%d,%d=",x,y);
	} else if ( REG_getP( r[y], x )) {
		REG_set1( r[x], y ); //printf("*%d,%d*",x,y);
	}
}
int steckers() {
	int i, j, bits1, des1, let_un, let_deux, let_trois;

	// initialistatons
	FL_sss_OK = FALSE;
	FL_csko_OK = TRUE;
	FL_mg_OK = TRUE;
	for(i=0;i<26;i++) {
		les_steck.IN[i]=i+'A';
		les_steck.OUT[i] = 0;
	}
	for(i=0, bits1=0;i<26;i++) {
		if ( flag[i] ) {
			for(j=0;j<26;j++)
				if( REG_getP( r[i] , j )) bits1 ++;
			break;
		}
	}
	if ( bits1 > 1 ) des1 = 1; else des1 = 0;

	// on le rempli
	for(i=0;i<26;i++) {
		if ( REG_isGood( r[i] ) )
			les_steck.OUT[i] = REG_premier( r[i], des1 )+'A';			
	}

	// on teste SSS
	for(i=0;i<26;i++) {
		if ( les_steck.OUT[i] )
			if ( les_steck.IN[i] == les_steck.OUT[i] ) {
				FL_sss_OK = TRUE;
				break;
			}
	}

	// on teste CSKO
	for(i=0;i<26;i++) {
		if ( les_steck.OUT[i] ) {
			let_un = les_steck.IN[i] -'A';
			let_deux=les_steck.OUT[i] -'A';
			if ( (let_un+1)%26 == let_deux ) FL_csko_OK = FALSE;
			if ( (let_un-1+26)%26 == let_deux ) FL_csko_OK = FALSE;
		}
	}

	// on teste Machine GUN
	for(i=0;i<26;i++) {
		if ( les_steck.OUT[i] ) {
			let_un = les_steck.IN[i] -'A';
			let_deux=les_steck.OUT[i] -'A';

			if ( les_steck.OUT[let_deux] ) {
				let_trois = les_steck.OUT[let_deux]-'A';
				if ( let_trois != let_un ) FL_mg_OK = FALSE;
			}
			for(j=0;j<26;j++) {
				if ( j != i && let_deux ==(les_steck.OUT[j]-'A'))
					FL_mg_OK = FALSE;
			}
		}
	}
}
