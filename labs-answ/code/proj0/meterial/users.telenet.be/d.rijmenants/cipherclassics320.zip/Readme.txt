
 --------------------------------------------------------------------
 CIPHER CLASSICS v3.2
 --------------------------------------------------------------------

 Content:

 1. Description
 2. Installation
 3. Copyrights


 --------------------------------------------------------------------
 1. Description
 --------------------------------------------------------------------

 Text encryption program with a list of classic field-ciphers.
 Encrypt swift and easy with this program, or try out the
 pencil-and-paper versions by following the instructions on how
 to use them "in the field", as many secret agents and soldiers did.
 Learn how tu use the famous classic cihpers, ADFGVX, Caesar Shift,
 Single or Double Columnar Transposition, Playfair, the Straddling
 Checkerboard or Vigen�re.

 As of version 2.2, the Wheatstone Cryptograph is added to the
 Cipher Classics program. This extension was written by Moshe Rubin
 from Israel.


 --------------------------------------------------------------------
 2. Installation
 --------------------------------------------------------------------

 System requirements: Windows 98 or higher.

 To install the program:
 Open with Winzip � and choose install, or extract to empty folder
 and run setup.exe.

 To uninstall:
 Open the configuration screen, choose software, select
 'Crypto Classics' in the list of programs and click the Add/Remove button.

 Please uninstall any previous version through config screen/software
 and remove 'Cipher Classics"' before installing the new version!

 What's new on this version:

 3.2 Fixed bug on Wheatstone when using more than one starting letter
 3.1 Fixed bug on decoding Wheatstone and expanded it paper version
 3.1 Fixed bug on Wheatstone when plaintext ends on double letters
 3.0 cleared bug playfair key initialization
 3.0 cleared bug "to clipboard" menu 

 --------------------------------------------------------------------
 3. COPYRIGHT NOTICE
 --------------------------------------------------------------------
 THIS PROGRAM IS FREEWARE AND CAN BE USED AND DISTRIBUTED UNDER THE
 FOLLOWING RESTRICTIONS: IT IS STRICKTLY FORBIDDEN TO USE THIS SOFT-
 WARE, COPIES OR PARTS OF IT FOR COMMERCIAL PURPOSES, SELL, LEASE
 OR MAKE PROFIT OF THIS PROGRAM BY ANY MEANS. THIS SOFTWARE MAY ONLY
 BE USED WHEN AGREEDING THESE CONDITIONS.

 DISCLAIMER OF WARRANTIES

 THIS SOFTWARE AND THE ACCOMPANYING FILES ARE SUPPLIED "AS IS" AND 
 WITHOUT WARRANTIES OF ANY KIND, EITHER EXPRESSED OR IMPLIED, WITH
 RESPECT TO THIS PRODUCT, ITS QUALITY, PERFORMANCE, MERCHANTABILITY,
 OR FITNESS FOR ANY PARTICULAR PURPOSE. THE ENTIRE RISK AS TO IT'S
 QUALITY AND PERFORMANCE IS WITH THE USER. IN NO EVENT WILL THE
 AUTHOR BE LIABLE FOR ANY DIRECT, INDIRECT, OR CONSEQUENTIAL DAMAGES
 RESULTING OUT OF THE USE OF OR INABILITY TO USE THIS PRODUCT.

 --------------------------------------------------------------------
 � D. Rijmenants 2005 - 2013 mailto: dr.defcom@telenet.be
 --------------------------------------------------------------------
