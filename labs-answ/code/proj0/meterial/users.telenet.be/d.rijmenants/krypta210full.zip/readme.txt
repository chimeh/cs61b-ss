
 ----------------------------------------------------------------------
 KRYPTA v2.1.0 Clipboard Encryption Tool - Readme
 ----------------------------------------------------------------------
 
 Please read the content of this readme carefully before installing and
 using KRYPTA. It contains important information about the software and
 provides additional information on security and cryptography.

 Content

 1. Description
 2. Installation & Version Info
 3. How To Use KRYPTA
 4. Solving Problems
 5. Why Should I Use Cryptography?
 6. Security issues
 7. Technical Details
 8. Disclaimer & Copyrights

 ----------------------------------------------------------------------
 1. Description
 ----------------------------------------------------------------------

 KRYPTA is a clipboard encryption tool. It is mainly designed to offer
 easy-to-use encryption to protect your e-mail communication and other
 text based programs. This small program provides a basic but strong
 encryption in a practical user-interface. KRYPTA is ideal for people
 who don't want to use complex encryption software but want to secure
 their communication. A full description of the symmetric encryption
 algorithm is provided in this Readme and is easy to implement, even by
 novice programmers, thus making it easy to apply or adapt in different
 programming languages and on different platforms in various compatible
 software applications.

 What does KRYPTA offer? KRYPTA offers basic but good protection and
 message confidentiality by a symmetric encryption algorithm that is
 small, fast and easy to implement by other programmers. It provides
 message integrity by rendering the plaintext always unreadable if one
 or more ciphertext bits are altered. With a properly selected key or
 passphrase (see Security Issues section), KRYPTA will resist a brute
 force attack, and an attack on the ciphertext will require vast
 computational and cryptanalytic resources, performed on large amounts
 of encrypted data, which will not guarantee successful decryption by
 the attacker. KRYPTA does not offer unbreakable encryption. KRYPTA
 does not provide key management. KRYPTA does not protect your computer
 against intrusion by malware that can intercept unprotected
 information before it is encrypted. KRYPTA does not prevent the
 detection of cryptographic software on your computer.

 If you want to use encryption extensively to protect large amounts of
 message traffic, files or hard-disk partitions, you should consider
 using other crypto software solutions such as PGP, CryptoForge or
 open source software like GnuPG or TrueCrypt.


 ----------------------------------------------------------------------
 2. Installation & Version Info
 ----------------------------------------------------------------------

 KRYPTA runs under Windows 98 or higher.

 To install the full version that includes all required run-time files,
 open the zip file and select 'install' or extract the files to an
 empty folder and run setup.exe

 The KRYPTA program without run-time files can be extracted to any
 folder. If the required run-time files are not installed on the
 computer, you will need to install the full installation version.

 To uninstall:
 Open the configuration screen, choose software, select 'KRYPTA' in
 the list of programs and click the Add/Remove button.

 Please uninstall previous versions before installing an update!

 Version Info:

 All published versions are compatible in Default mode.
 
 v0.1.0  beta
 v1.0.0  first version
 v1.0.1  code optimized
 v1.0.5c extended config
 v1.0.7c changed caption config
 v2.0.0  Added options window and settings saved in config.dat file
 v2.1.0  Added ouptut choice Hex/Base64/Letter-only


 ----------------------------------------------------------------------
 3. How To Use KRYPTA
 ----------------------------------------------------------------------
 
 KRYPTA uses symmetric encryption. Encryption and decryption are
 performed with the same key. Therefore, the key must be shared by all
 parties that wish to exchange encrypted messages with each other.

 The clipboard is used as interface between KRYPTA and other software.
 Encrypting a message only requires few steps.

 === Encryption ===

 1. Enter your message text in the KRYPTA textbox.
 2. Select the 'Encrypt' menu.
    You will be prompted to enter a key, if not already entered.
    The messages is encrypted and automatically sent to the clipboard.
 3. Paste (ctrl+v) the clipboard content to any e-mail or text-editor
    program.

 === Decryption ===

 1. Select and copy (ctrl+c) the encrypted text from any program to
    the clipboard.
 2. Go to KRYPTA and select the 'Decrypt' menu.
    You will be prompted to enter a key, if not already entered.
    The decrypted text is displayed in the KRYPTA textbox.

 === Other features ===

 When copying an encrypted message from another program to the
 clipboard, the program will automatically strip all unwanted heading
 and trailing characters and will only process the character as set
 in the options window.

 When a message is successfully encrypted to the clipboard, the KRYPTA
 textbox will turn green. A successful decryption will turn the KRYPTA
 textbox red. The textbox will be white during text editing.

 With the 'Key' menu you can enter a new key or change the current key.
 When a new key is entered, the program will calculated the bit-
 strength of that key and give an indication of the key quality.
 A 80 bit key strength is recommended by NIST, as this key size is
 generally accepted as impossible to brute-force with current and
 future technology. Too small or repetitive keys are refused by the
 program. Please read more about selecting good keys in the 'Security
 Issues' section.

 There is a Key cache of 2 minutes. After not using the program for
 more than 2 minutes the key and clipboard will be erased. After 10
 minutes of inactivity the textbox will also be erased, to protect the
 key and text if the program is left unattended.

 The 'Clear' menu will clear the textbox. Select the 'Word Wrap' menu
 to switch to automatic word wrapping.

 The KRYPTA text box is limited to 32,000 character.

 The clipboard is automatically cleared if the program is closed. Do
 not close KRYPTA before you have pasted your encrypted data to the
 target program!

 === Customizing KRYPTA ===

 You can customize KRYPTA by selecting 'Options' in the 'Extra' menu.
 These settings are saved in a file called "krypta.dat", located in
 the same folder as the KRYPTA program. If KRYPTA is executed from a 
 read-only medium it will be impossible to save the settings. Make
 sure the "krypta.dat" file is not read-only could occure after you
 copied the files from a read-only medium.

 Note that this KRYPTA version is backward compatible with previous
 versions. This however is only when the Default settings are selected!
 
 * General Options *

 'Customize Settings on Startup' enables customized crypto settings
 to be loaded on startup of the program

 'No 2 Minutes Key Cache' will prevent that the entered key is
 memorised for 2 minutes before being erased.

 'Auto Close on Startup' will terminate the program automatically 
 after 10 minutes of non-activity.

 * Format Option *

 'Word Wrap on Startup' will set the KRYPTA textbox in wordwrap mode
 when the program is started.

 When the text is encrypted, the output that is sent to the clipboard
 is formatted into groups. With 'Characters per Group' and 'Groups per
 Line' you can set the format of the output.

 * Custom Crypto Settings *

 With these settings you can personalize the crypto algorithm. This
 enables the creation of an exclusive user group.

 WARNING: these settings will affect the operation of the crypto 
 algorithm. If you use KRYPTA to communicate with others, the
 settings of both sender and receiver must be identical. Loss of
 these settings will render all data, encrypted with these settings,
 useless.

 - 'Output Format' sets the type of output characters. You have the
   choice between hexadecimal, base26 and letters-only:

   Hexadecimal : 00-ff (0123456789abcdef)
   Base26      : A-Z, a-z, 0-9, /+= 
   Letters-only: A-Z

   Note that encrypting in a given output type will require the same
   settings to correctly decrypt the data.

 - 'Initialisation Vector Size' determines the size of the IV that is
   added to the key to ensure a unique encryption output, even with
   identical key and plain text.

 - 'Initialisation Loops' sets the number of times the key if mixed.

 - 'Drop Bytes' sets the number of bytes that are discarded at the 
   beginning of the encryption to prevent analysis of the initial
   key state.

 - 'Custom Caption Title' is the text that is displayed at the top
   of the program window if the Custom mode is selected.

 The vector size, initialisation loops and number of drop bytes can
 be set to any desired value withing the safe ranges that are limited
 by the program.

 The Letters-Only output enables the encrypted data to be transmitted
 by means that can only process alphabetic characters. This makes it
 possible to send a message, containing the full character range of
 uppercase, lowercase, numbers and symbols by Morse, voice over radio
 or telephone. The most convenient way by voice is to use the standard
 phonetic alphabet:

 Alpha     Golf    Mike       Sierra    Yankee
 Bravo     Hotel   November   Tango     Zulu
 Charlie   India   Oscar      Uniform
 Delta     Juliet  Papa       Victor
 Echo      Kilo    Quebec     Whiskey
 Foxtrot   Lima    Romeo      X-Ray

 * Special Hidden Option *

 There is a special hidden setting to disables the 'Extra' menu. This
 prevents the user to change the options or to switch between default
 and custom mode. This is interesting when you want others to use the
 program only in a pre-determined mode. In Default mode this prevents
 the user to customize the settings. In Custom mode this prevents the
 user to change or disable the custom settings.

 How to disable the 'Extra' menu:

 1. Select all desired settings in the 'options' menu.
 2. If you want to use only the Default mode, click the 'Set Defaults'
    button to erase any custom settings and uncheck (disable) the
    'Custom Settings on Startup' option.
 3. If you want to use only the Custom settings, select the desired
    settings and check (enable) 'Custom Settings on Startup'. If this
    option is not checked, KRYPTA won't start in Custom mode!    
 4. Close the KRYPTA program.
 5. Open the "krypta.dat" settings file (in the KRYPTA program folder)
    with notepad or a similar text editor, change the 8th character
    from 0 into 9 and save it.
 6. On the next startup, the 'Extra' menu will no longer be visible.

 To restore the original menu layout, change the 8th character back
 into 0 (zero) or simply delet the "krypta.dat" settings file (a new
 file is created automatically on saving the settings the next time).


 ----------------------------------------------------------------------
 4. Solving Problems
 ----------------------------------------------------------------------

 Installation fails/ user is asked to overwrite file(s)

 - If a previous version has been uninstalled, it is possible that an
   old settings file isn't deleted. Select overwrite/Yes during
   installation or delete old install folder "KRYPTA" first.

 The program doesn't work/ reports DLL or system errors

 - If you are using the "KRYPTA.exe" file without a full installation
   your system may not have the required runtime file. Run the full
   installation to install the required runtime files.

 Incorrect decryption although a correct key is used:

 - The that needs to be decrypted is copied incorrectly to the
   clipboard, is incomplete or contains errors.
 - The crypto settings are incorrect during decrypting or the wrong
   Default/Custom mode is selected.
 - The person who encrypted the data has used incorrect crypto
   settings or used the wrong Default/Custom mode.
 - Wrong Output Format (Hex/Base26/Letters-only) selected.

 Extra/Options menu not available

 - Menu locked in settings menu. Delete "krypta.dat" file in program
   folder or open the file with a notepad and change the 8th digit
   into 0 (zero)

 Unable to select 'Custom Settings' in the Extra menu

 - There are no customized settings available.

 You entered a key but it is no longer available

 - You exceeded the key cache time of 2 minutes and the key is 
   automatically cleared.
 - The 'No Key Cache' option is check and the key is not memorized.

 Program closes down without being closed by the user

 - The 'Auto Close' option is checked and terminates the program
   automatically after 10 minutes.

 Error when saving the settings

 - KRYPTA is started from a read-only media (CDR, locked diskette or
   locked USB stick. Use a read/write media or unlock it
 - The "krypta.dat" settings file has read-olny properties (possible
   when copied from read-only media). Right-click the file and uncheck
   the read-only option.


 ----------------------------------------------------------------------
 5. Why Should I Use Cryptography?
 ----------------------------------------------------------------------

 Would you write every message on the back of a postcard, visible to
 everyone, instead of using an envelope? Of course not, some things are
 private. That's why we need cryptography. To safeguard our privacy.
 Today, most of our communication is sent by e-mail. Once you have
 pushed the send button you have no idea of the route your message
 takes through many servers. Your e-mail could easily be intercepted
 and read without you even noticing it.

 If your e-mail did arrive safely, can you be sure that the recipients
 computer isn't left unattended, enabling strangers to read your
 message? Did the recipient deleted your message completely after
 reading it, or is it still in the delete folder of his e-mail program?
 Are you sure there are no traces left on your computer? Do you clear
 your Sent Items folder and constantly empty your recycle bin? You
 never leave your computer alone? It's because we humans are generally
 not paranoia that we tend to make so many security mistakes. The fact
 is that you'll never be sure that some information isn't compromised.

 There are many ways for others to read your confidential mail. The
 only way to prevent this, is to use cryptography. Your messages are
 not confidential? What about the date of your Holiday weeks, or that
 weekend away, when your house is left unattended? And that e-mail about
 those health problems? Imagine someone, by accident of course, reading
 that message to your wife about your finances, or a colleague, bumping
 into your comments on his work. Or a quick mail because your wife
 forgot that pin code, again. Reasons enough to encrypt your messages.

 With KRYPTA, your message is edited in the KRYPTA textbox and the
 clipboard will only contain encrypted information. The unprotected
 message is never stored on your computer. All message copies, stored
 in e-mail folders or other locations, will required the correct
 password to decrypt them. Even when you leave KRYPTA unattended, a
 cache timer clears your key and message after a short while. If KRYPTA
 is used, you can be confident that your message is read only by the
 person it was intended for.


 ----------------------------------------------------------------------
 6. Security issues
 ----------------------------------------------------------------------

    a. Keywords and Passwords

 The security of KRYPTA depends entirely on the quality of the key. An
 indication to the bit-strength of the key is given by KRYPTA when the
 key is entered. However, this indication is not absolute, and doesn't
 check if the key isn't vulnerable to, for instance, dictionary
 attacks. There are some basic tips to select good keys:

 Never use words, names, dates, abbreviations or other existing
 combinations! These are vulnerable to dictionary attacks. While a
 good key word has an infinity of combinations, a dictionary attack can
 reduce actual words to a few million or even thousands. Fast computers
 can process them in relative short time.

 Use a combination of upper case and lower case, numbers and symbols
 for key words. A five letter combination of only lower case letters
 gives you only 11,881,376 possible different combinations. If you use
 upper and lower case letters and numbers, there are already
 916,132,832 combinations. An eight character password has 2.18e+14
 or 218 trillion possible combinations. Each additional character
 multiplies this with number with 62! Never use repetitions like
 '123123' or 'mamama'.

 Another way to compose your key is the use of a pass-phrase. Here we
 need other calculations. A normal language has an average vocabulary
 of about 5000 words. A pass-phrase with four words has 6.25e+14 or
 625 trillion possible combinations. This applies only on a phrase
 with random words, and no real sentences. If you use words in a logic
 order or a real sentence, the number of combination will be reduced.

    b. The Computer

 Every external connection on your computer is a security risk.
 There is always a possibility that others retrieve information from
 your computer through a network connection. This can be by remote
 control, Trojan horses or spyware, sending your files to others,
 capture keystrokes or screenshots. Therefore a stand-alone computer
 is recommended to store your crypto utilities. Even the most powerful
 encryption system is as weak as the most dangerous security flaw in
 your computer!


 ----------------------------------------------------------------------
 7. Technical Details
 ----------------------------------------------------------------------

 In this section you will find a complete description of KRYPTA. You
 can use this information to create your own software version of KRYPTA.
 Please make sure to write your code in such way that it is fully 
 compatible with KRYPTA. The name KRYPTA should only be used if the
 program is fully compatible. Note that this description explain only
 the default mode.

 KRYPTA uses a symmetric encryption algorithm with variable length key
 with Initialisation Vector and is based on ARCFOUR, but features
 several improvements to provide better security against cryptanalysis.
 The original ARCFOUR (the alleged RC4) had some important
 disadvantages. The Fluhrer-Mantin-Shamir attack, which found biases
 in the first few generated bytes, and more recently the Tews-Pychkine-
 Weinmann attack showed that 80,000 WEP packets, using the same key and
 48 bit IV, could be sufficient to retrieve the key.

 The algorithm as applied in KRYPTA uses a 256 bit (32 byte)
 Initialisation Vector, appended to the key, to ensure a unique
 encryption, even with identical key and plaintext. The key
 initialisation loop is repeated 24 times to ensure a good mixing of
 the array bytes. In order to drop the key related bytes, the first
 3072 generated bytes are disregarded. Also, a cipher-feedback mode
 is implemented and each encrypted byte will therefore influence the
 next permutation of the array bytes, making a single decryption error
 fatal to the rest of the ciphertext. Thanks to these improvements
 the algorithm provides a fast, reliable and strong encryption.
 Although the messages volume, as used with KRYPTA, is too small for
 successful cryptanalysis and recovery of the key, it is recommended
 to regularly (<2Gb) change the encryption key.

 The encryption output is composed of the 32 IV bytes, followed by the
 encrypted text. In order to keep the source code compact and easy to
 apply for other programmers, the uncompressed output bytes are
 converted into hex values, which are accepted by any text editor or
 e-mail program. The program will read hex values (A-F, 0-9) only in
 the ciphertext and disregards all other characters.

 When designing your own program with this algorithm you will need to
 make sure that the user can only enter good non-repetitive keys with
 sufficient bit strength. In KRYPTA the following formula was used
 to calculate the bit strength and give a key quality indication:

 Bit strength = log(C^L)/log(2)

 Where C is the character variation and L the length of the key. If for
 example a key is composed of upper and lower case letters only, then
 C=52, and if it contains also digits C=62. Including also spaces and
 signs will raise C to 88.

 Below are given the VB Source code snippets with the core elements of
 KRYPTA. These will help programmers to write their own compatible
 version.

 >>> module vars <<<

 Private s(255) As Integer
 Private P1     As Integer
 Private P2     As Integer

 >>> key initialisation <<<

 Don't forget to append a random IV of 32 bytes at the end of the key
 before initialising the key. Once the data is encrypted, the (not
 encrypted!) IV must be added at the beginning of the ciphertext. The
 random IV doesn't have to be crypto secure random, just good random.
 To decrypt, read in and append the IV to the key first, and then
 decrypt the rest of the message.


 For i = 0 To 255
     s(i) = i
 Next
 'transpose s-array 24 times with key
 For k = 1 To 24
     For i = 0 To 255
         j = (j + s(i) + key(i Mod KeyLen)) Mod 256
         tmp = s(i)
         s(i) = s(j)
         s(j) = tmp
     Next
 Next

 >>> Encryption Loop <<<

 CFB = 0
 'dump first 3072
 For k = 1 To 3072
     dummy = KRYPTA(CFB)
 Next
 'encryption loop
 For k = 0 To Ubound(text)
     i = text(k) Xor KRYPTA(CFB)
     text(k) = i
     CFB = i
 Next

 >>> Decryption loop <<<

 'decode cycle
 CFB = 0
 'dump first 3072
 For k = 1 To 3072
     dummy = KRYPTA(CFB)
 Next
 'decryption loop
 For k = 0 To Ubound(text)
     i = text(k)
     text(k) = i Xor KRYPTA(CFB)
     CFB = i
 Next

 >>> KRYPTA function <<<

 Private Function KRYPTA(feedback As Byte) As Byte
 Dim tmp As byte
 P1 = (P1 + 1) Mod 256
 P2 = (P2 + s(P1) + feedback) Mod 256
 tmp = s(P1)
 s(P1) = s(P2)
 s(P2) = tmp
 KRYPTA = s((s(P1) + s(P2)) Mod 256)
 End Function


 >>> Test Vectors <<<

 When you perform these tests, make sure that your code will only
 read the ciphertext hex chars (A-F,0-9) and no other letters, line
 feeds or signs. The program should accept both upper case and lower
 case version of the hex values.

 The first test should always produce the same output. Make sure to 
 use the fixed IV (only for test purposes!). This test can be used to
 verify both encryption and decryption.

 Key: ABCDabcd1234
 Text: The Quick Brown Fox Jumps Over The Lazy Dog
 Non random test IV: 32 x &H80 (ASCII value 128)
 Result:
 80808080808080808080808080808080808080808080808080808080808080805e8f
 c06a33d4b4d54e9de4c6d0a623159e0659eba027bdf4d51a576a44b70eb6a6edb333
 156ffdc4b04698

 Output is 32 x &h80 (IV) followed by the 43 hex values of the
 encrypted text.

 The second test uses a random IV. Do not use this test to verify the
 encryption result, since the IV, and therefore also the output, will
 always differ. Use it to verify the decryption output only.

 Key : ABCDabcd1234
 Ciphertext (with random IV):
 017d27405fb2d77dfb1e119896cfb9af5f88954366665ff753c31995585ba1520217
 e772a8915c884333ee7e1900b77a6ea55a476d41bb5a2f753baa5752cf5ebbf7d73a
 26f8866174d41e
 Result: The Quick Brown Fox Jumps Over The Lazy Dog


 ----------------------------------------------------------------------
 8. Disclaimer & Copyrights
 ----------------------------------------------------------------------

 THIS PROGRAM IS FREEWARE AND CAN BE USED AND DISTRIBUTED UNDER THE
 FOLLOWING RESTRICTIONS: IT IS STRICTLY FORBIDDEN TO USE THIS SOFTWARE
 OR COPIES OR PARTS OF IT FOR COMMERCIAL PURPOSES, OR TO SELL, TO LEASE
 OR TO MAKE PROFIT FROM THIS PROGRAM BY ANY MEANS. THIS SOFTWARE MAY
 ONLY BE USED IF YOU AGREE TO THESE CONDITIONS.

 THE NAME KRYPTA MAY ONLY BE USED IN OTHER SOFTWARE IF THAT SOFTWARE
 IS FULLY COMPATIBLE WITH THE ORIGINAL KRYPTA SOFTWARE. PLEASE CHECK
 THE TECHNICAL DETAILS FOR COMPATIBILITY INFORMATION.

   IMPORTANT NOTICE

 ABOUT RESTRICTIONS ON IMPORTING STRONG ENCRYPTION ALGORITHMS:

 THE KRYPTA ENCRYPTION ALGORITHM USES A LENGTH-VARIABLE KEY. IN SOME
 COUNTRIES IMPORT OF THIS TYPE OF SOFTWARE IS FORBIDDEN BY LAW OR HAS
 LEGAL RESTRICTIONS. CHECK FOR LEGAL RESTRICTIONS ON THIS SUBJECT IN
 YOUR COUNTRY.

   DISCLAIMER OF WARRANTIES
 
 THIS SOFTWARE AND THE ACCOMPANYING FILES ARE SUPPLIED "AS IS" AND
 WITHOUT WARRANTIES OF ANY KIND, EITHER EXPRESSED OR IMPLIED, WITH
 RESPECT TO THIS PRODUCT, ITS QUALITY, PERFORMANCE, MERCHANTABILITY,
 OR FITNESS FOR ANY PARTICULAR PURPOSE. THE ENTIRE RISK AS TO ITS
 QUALITY AND PERFORMANCE IS WITH THE USER. IN NO EVENT WILL THE AUTHOR
 BE LIABLE FOR ANY DIRECT, INDIRECT, OR CONSEQUENTIAL DAMAGES RESULTING
 OUT OF THE USE OF OR INABILITY TO USE THIS PRODUCT.

 ----------------------------------------------------------------------
 � D. Rijmenants 2009
 DR.Defcom@telenet.be
 http://users.telenet.be/d.rijmenants
 ----------------------------------------------------------------------

