----------------------------------------------------------------------
 Crypto Box v2.0 ReadMe
 ----------------------------------------------------------------------

 Content:

 1. Description
 2. Installation
 3. Copyrights and Disclaimer

 ----------------------------------------------------------------------
 1. Description
 ----------------------------------------------------------------------

 The Crypto Box is a tool to encrypt text by moving the letters. This
 is done by shuffling the rows and columns of the letters square.
 Retrieving the original position of the letters has proved to be a
 real challenge due to the large number of possible moves and the
 complex way the letters travel around the square. Even the simplest
 shuffles with a few steps create a most complex transposition.

 Please read 'CryptoBox Help.txt' for operating instructions.

 Version Info:

 v1.0.0 First version
 V2.0.0 New shift buttons, easier recording of steps, new menus
 v2.0.1 Added memory/recall/clear to key menu


 ----------------------------------------------------------------------
 2. Installation
 ----------------------------------------------------------------------

 System requirements: Windows 98 or higher, mouse installed.

  a. Full Installation

 This installation contains all required run-time files. Open the
 installation zip with Winzip or IZArc and choose install, or extract
 to an empty folder and run setup.exe.

 To uninstall: Open the configuration screen, choose software, select
 'CryptoBox' in the list of programs and click the Add/Remove button.


  b. Exe-only Installation

 This installation will only work when the required run-time files
 are already on your systems. Open the zip with Winzip or IZArc and
 extract the files 'CryptoBox.exe', 'CryptoBox Help.txt' and 'Readme'
 to any desired folder.

 To uninstall: simply delete the files.
 

 
 ----------------------------------------------------------------------
 3. Copyrights & Disclaimer
 ----------------------------------------------------------------------

 THIS PROGRAM IS FREEWARE AND CAN BE USED AND DISTRIBUTED UNDER THE
 FOLLOWING RESTRICTIONS: IT IS STRICTLY FORBIDDEN TO USE THIS SOFTWARE
 OR COPIES OR PARTS OF IT FOR COMMERCIAL PURPOSES, OR TO SELL, TO LEASE
 OR TO MAKE PROFIT FROM THIS PROGRAM BY ANY MEANS. THIS SOFTWARE MAY
 ONLY BE USED IF YOU AGREE TO THESE CONDITIONS.


    DISCLAIMER OF WARRANTIES
 
 THIS SOFTWARE AND THE ACCOMPANYING FILES ARE SUPPLIED "AS IS" AND
 WITHOUT WARRANTIES OF ANY KIND, EITHER EXPRESSED OR IMPLIED, WITH
 RESPECT TO THIS PRODUCT, ITS QUALITY, PERFORMANCE, MERCHANTABILITY,
 OR FITNESS FOR ANY PARTICULAR PURPOSE. THE ENTIRE RISK AS TO IT'S
 QUALITY AND PERFORMANCE IS WITH THE USER. IN NO EVENT WILL THE AUTHOR
 BE LIABLE FOR ANY DIRECT, INDIRECT, OR CONSEQUENTIAL DAMAGES RESULTING
 OUT OF THE USE OF OR INABILITY TO USE THIS PRODUCT.

 ----------------------------------------------------------------------
 � D. Rijmenants 2007
 mailto: DR.Defcom@telenet.be
 http://users.telenet.be/d.rijmenants
 ----------------------------------------------------------------------

