------------------------------------------------------------------------
RASTERSCHL�SSEL 44 EXCEL SHEET README                       Version 2.1
------------------------------------------------------------------------

With the Rasterschl�ssel 44 Excel Sheet generator you can create and 
print RS 44 key sheet templates.

This Excel sheet contains a Marco function to copy and convert random
clipboard content to the key sheet template. This Macro cannot run when
your Excel Macro Security Settings are set to High or Very High. If you
want to use the RS 44 clipboard function, make sure that your Macro
security settings are set to Low or Medium. To change this in Excel,
go to Tools - Option, select the Security tab and click Macro Security.

Warning:

Excel sheets of unknown origin could contain Macro viruses that can
harm your computer. Therefore, it is advised to set the Macro Security
option at least on Medium. In that case, Excel will ask you whether you
thrust the Excel sheet and enable the Macros, or to disable them.

------------------------------------------------------------------------
Setting the Rasterschl�ssel 44 Key Variables
------------------------------------------------------------------------

The formatting of the column and row labels, and the black blocks of the
template are composed automatically. The information to set them is 
entered in the yellow fields. The two place name alphabets and conversion
alphabet are entered directly in the template sheet.

If desired, you can enter message text in the template grid fields.

To prepare a RS 44 key sheet, we must provide the following information:

* Column digraph label order:

   25 unique values between 1 and 25 (first horizontal yellow row of
   fields at the top)

* Column Number label order:

   25 unique values between 1 and 25 second horizontal yellow row of
   fields at the top)

* Row digraph label order:

   24 unique values between 1 and 24 (vertical yellow field)

* RS 44 Grid Layout:

   To make a black or white field, enter either the digits 0 or 1, the
   numbers 0 through 9 or the letters A through Z in the yellow grid
   field. Odd numbers create a black cell on the key sheet and even
   numbers a white white cell.

   You can use the Clipboard function to automatically load an convert
   random or formatted clipboard data from another program into the
   grid layout. Once you have copied that data, got the the RS 44 sheet
   and click the "Clipboard to Grid Layout" button. This function
   accepts all digits, but also letters (A, C, D... create black cells
   and (B, D, F... create white cells). The function needs 600 numbers
   or letters. A crypto-secure random number generator is available at
   http://users.telenet.be/d.rijmenants/en/numbersgen.htm

* Two Place Name Alphabets:

   Two series of 26 unique letters (A through Z) entered directly in
   the two white horizontal template sheet fields

* Letter Conversion Alphabet (for Digraph encoding):

   26 unique letters (A through Z) entered directly in the white 
   template sheet square fields


Notes:

The term "unique" means that each of the numbers or letters occurs
only once in that particular field.

You can use truly random digits or letters for the Clipboard function
(for instance from a crypto-secure generator). The RS 44 however had
a fixed number of 10 white fields in each row.

All other elements, cells and formatting in the Excel sheet is protected
(without password)to prevent accidental changing of format or formulas.

------------------------------------------------------------------------
� Dirk Rijmenants 2012 
Cipher Machines and Cryptology
http://users.telenet.be/d.rijmenants
------------------------------------------------------------------------